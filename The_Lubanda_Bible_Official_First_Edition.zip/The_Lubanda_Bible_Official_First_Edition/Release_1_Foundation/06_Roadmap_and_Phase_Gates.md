---
title: "Roadmap and Phase Gates"
document_code: "LNGP-R1-06"
release: "Release 1 — Foundation"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Roadmap and Phase Gates

**Document Code:** LNGP-R1-06  
**Release:** Release 1 — Foundation  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Phase 0 — Foundation

Deliverables:
- Constitution
- Vision
- Architecture
- Data contracts
- Acceptance criteria

Exit gate: no unresolved contradiction in core principles.

## Phase 1 — Data and Genealogy

Deliverables:
- Excel import
- schema mapping
- validation reports
- canonical genealogy graph
- test datasets

Exit gate: all genealogy tests pass; invalid inputs are blocked before rendering.

## Phase 2 — Skeleton Engine

Deliverables:
- trunk and branch centerlines
- territory planner
- collision-safe path growth
- debug view
- deterministic seeds

Exit gate: representative datasets generate connected, non-crossing skeletons.

## Phase 3 — Labels and Stability

Deliverables:
- readable labels
- search anchors
- incremental updates
- branch and node movement constraints

Exit gate: edits preserve unrelated geometry and labels remain collision-free.

## Phase 4 — Performance and Scale

Deliverables:
- spatial indexing
- progressive solving
- benchmarks at 10, 100, 500, and 1,500 people
- profiling reports

Exit gate: target hardware remains interactive for navigation and completes solving within defined budgets.

## Phase 5 — Visual System

Deliverables:
- bark rendering
- leaves for terminal persons
- themes
- template boundaries
- high-quality export

Exit gate: visual rendering preserves approved skeleton and passes export validation.

## Phase 6 — Platform

Deliverables:
- production UI
- authentication if required
- project persistence
- version history
- collaboration
- deployment

Exit gate: release checklist complete.

## Prohibition

No phase may be declared complete because the interface looks impressive. Completion is defined by acceptance evidence.
