---
title: "Design Philosophy and Rule Zero"
document_code: "LNGP-R1-03"
release: "Release 1 — Foundation"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Design Philosophy and Rule Zero

**Document Code:** LNGP-R1-03  
**Release:** Release 1 — Foundation  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Rule Zero

> If the generated tree looks like rigid computer graphics rather than naturally grown structure, the implementation has failed—even when formal constraints pass.

Rule Zero does not override genealogy, readability, or collision safety. It becomes decisive after mandatory correctness has been achieved.

## 1. Core Philosophy

Lubanda does not optimize a picture. It simulates constrained growth.

The engine asks:
- Where is safe space available?
- Which lineage needs more territory?
- Which direction preserves continuity?
- Which option avoids future congestion?
- Which curve looks plausible for a branch of this thickness and role?

It does not begin with:
- fixed levels,
- equal angles,
- mirrored layouts,
- semicircular crowns,
- uniform radial fans.

## 2. Truth Before Beauty

Visual quality is important, but never at the cost of:
- wrong ancestry,
- hidden people,
- unreadable labels,
- false proximity,
- broken parent-child continuity.

## 3. Local Intelligence, Global Guidance

Natural growth is largely local, but a large genealogy needs global awareness. Lubanda therefore combines:
- global demand estimation,
- territory allocation,
- local path growth,
- collision checks,
- iterative relaxation.

Neither purely local nor purely global optimization is sufficient.

## 4. Shared Space

No branch owns immutable rectangular territory. Initial territories are planning aids, not walls. Branches may borrow or release space if:
- genealogical identity remains clear,
- crossings are prevented,
- neighboring lineages remain readable,
- the global objective improves.

## 5. Organic Asymmetry

Natural balance is not geometric symmetry. One side may be denser because one lineage has more descendants. The tree should look balanced in mass and readability, not mirrored.

## 6. Direction Freedom

A descendant may be visually:
- above,
- beside,
- slightly below,
- inward,
- outward,

provided the relationship remains unmistakable.

Generation is a data property, not a y-coordinate.

## 7. Progressive Thickness

Thickness represents structural role and accumulated descendant demand:
- trunk,
- primary branch,
- secondary branch,
- twig,
- terminal stem.

Thickness transitions must be gradual and physically plausible.

## 8. Growth Memory

Branches should preserve directional momentum. Sudden reversals, repeated S-curves, and sharp kinks are discouraged unless required to avoid a stronger conflict.

## 9. Stability Over Perfection

A slightly less optimal local placement is preferable when it preserves accepted geometry and prevents large unrelated changes.

## 10. Structural Honesty

Debug views must expose:
- skeleton paths,
- clearance zones,
- territory boundaries,
- label boxes,
- collision candidates,
- rejected path alternatives.

The system must make failure inspectable.
