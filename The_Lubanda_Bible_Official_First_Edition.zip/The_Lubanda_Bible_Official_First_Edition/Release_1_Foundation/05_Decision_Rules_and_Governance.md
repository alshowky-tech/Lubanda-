---
title: "Decision Rules and Governance"
document_code: "LNGP-R1-05"
release: "Release 1 — Foundation"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Decision Rules and Governance

**Document Code:** LNGP-R1-05  
**Release:** Release 1 — Foundation  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Decision Priority

When objectives conflict, use this order:

1. Genealogical correctness
2. Relationship readability
3. Collision avoidance
4. Structural continuity
5. Stability
6. Organic growth
7. Space utilization
8. Performance
9. Visual beauty

Lower priorities may never defeat higher ones.

## 2. Engineering Decision Record

Significant decisions should be recorded with:
- context,
- problem,
- considered alternatives,
- chosen decision,
- consequences,
- migration impact,
- approval.

## 3. Change Classes

### Class A — Constitutional
Changes project principles. Requires explicit owner approval.

### Class B — Architectural
Changes contracts, pipeline, or major engine responsibility. Requires design review and migration plan.

### Class C — Behavioral
Changes solver outcomes without altering public contracts. Requires benchmark and regression comparison.

### Class D — Cosmetic
Changes style only. Must prove no geometry or data change.

## 4. Evidence Standard

A proposal should include at least one of:
- benchmark,
- automated test,
- visual comparison,
- reduced complexity,
- improved correctness,
- documented user need.

## 5. Rejection Rules

Reject a proposal when it:
- modifies genealogy for appearance,
- hides collisions,
- creates uncontrolled nondeterminism,
- couples unrelated modules,
- cannot be tested,
- causes widespread unstable movement,
- improves one sample while degrading general behavior.

## 6. Versioning

Documentation and implementation versions should be traceable. Generated artifacts should embed:
- application version,
- engine version,
- schema version,
- document edition,
- seed,
- timestamp.

## 7. Conflict Resolution

When two documents conflict:
1. Constitution wins.
2. More specific official specification wins over a general guideline.
3. Newer approved version wins over an older version.
4. Ambiguity must be documented rather than guessed.
