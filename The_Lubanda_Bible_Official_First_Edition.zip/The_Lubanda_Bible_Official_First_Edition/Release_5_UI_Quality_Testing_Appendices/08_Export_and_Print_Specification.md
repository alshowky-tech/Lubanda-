---
title: "Export and Print Specification"
document_code: "LNGP-R5-08"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Export and Print Specification

**Document Code:** LNGP-R5-08  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Formats

- SVG
- PNG
- PDF
- interactive web package

## 2. SVG

Should preserve:
- vector paths,
- text where possible,
- IDs and metadata,
- viewBox,
- layers or groups.

## 3. PNG

Support:
- configurable pixel dimensions,
- transparent or solid background,
- 4K and larger outputs,
- tiled rendering for very large images.

## 4. PDF

Support:
- page size,
- poster tiling,
- embedded fonts or safe outlining,
- print margins,
- vector preservation.

## 5. Mural Export

Large-format export should use physical dimensions, DPI, bleed, and print-safe profiles.

## 6. Validation

Compare exported bounds and labels to the approved canvas.

## 7. Metadata

Embed or accompany:
- project name,
- revision,
- engine version,
- style profile,
- export settings,
- timestamp.

## 8. Privacy

Exports should include only approved metadata.
