---
title: "UI Information Architecture"
document_code: "LNGP-R5-01"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# UI Information Architecture

**Document Code:** LNGP-R5-01  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Primary Workspaces

- Projects
- Data Import
- Validation
- Tree Workspace
- Style
- Export
- History
- Administration

## 2. Tree Workspace Regions

- main canvas,
- navigation controls,
- genealogy inspector,
- branch inspector,
- solver status,
- issue panel,
- search,
- export actions.

## 3. Progressive Disclosure

Basic users see essential controls. Advanced solver parameters remain in expert panels.

## 4. RTL

The complete interface supports Arabic right-to-left layout without reversing spatial meaning of canvas coordinates.

## 5. State Visibility

Always show:
- current project,
- genealogy revision,
- layout status,
- unsaved changes,
- validation state,
- selected person or branch.

## 6. Error Presentation

Errors must identify the affected record or geometry and offer a direct navigation action.

## 7. No Decorative Obstruction

UI decoration must not reduce canvas area or hide diagnostics.
