---
title: "Glossary"
document_code: "LNGP-R5-11"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Glossary

**Document Code:** LNGP-R5-11  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Approved Skeleton
A structurally valid, collision-free centerline representation accepted before styling.

## Branch
A structural path corresponding to a lineage segment.

## Collision Envelope
The protected geometric region around an element.

## Demand
Estimated spatial requirement of a subtree.

## Genealogy Snapshot
Immutable normalized genealogy used for one solve.

## Growth Memory
Preference for preserving direction and prior accepted geometry.

## Junction
Connection where a child branch emerges from a parent wood path.

## Label Anchor
Geometric relationship connecting a person label to the skeleton.

## Layout Revision
A saved geometry result linked to a genealogy revision.

## Lineage
A person and the included descendants under that person.

## Rule Zero
The requirement that valid output must also avoid rigid computer-diagram appearance.

## Skeleton
The unstyled centerline structure of trunk, branches, and twigs.

## Stability
Property by which small data changes cause small layout changes.

## Terminal Person
A person with no descendants in the selected rendered subtree.

## Territory
A flexible spatial preference region assigned to a lineage.

## Topology
The parent-child connectivity of the genealogy and skeleton.

## Visual Profile
Versioned presentation settings that do not alter topology.
