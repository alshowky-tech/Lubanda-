---
title: "Acceptance Criteria"
document_code: "LNGP-R5-06"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Acceptance Criteria

**Document Code:** LNGP-R5-06  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Data Acceptance

- required columns recognized,
- no duplicate IDs,
- all parents resolved,
- no cycles,
- selected root valid,
- generations valid,
- all included people reachable.

## 2. Skeleton Acceptance

- continuous root path,
- all persons represented,
- no disconnected branches,
- smooth junctions,
- valid thickness hierarchy.

## 3. Collision Acceptance

- zero branch crossings,
- zero label overlaps,
- safety margins respected,
- no hidden crossings after bark.

## 4. Stability Acceptance

- local edits preserve unrelated branches,
- deterministic regeneration,
- locked geometry respected or explicitly reported impossible.

## 5. UX Acceptance

- pan and zoom work with mouse and touch,
- search finds Arabic names and IDs,
- issues navigate to affected elements,
- undo/redo works for editing operations.

## 6. Export Acceptance

- SVG preserves geometry,
- PNG supports target resolution,
- PDF prints correctly,
- Arabic text is correct,
- metadata records version and seed.

## 7. Scale Acceptance

Benchmark datasets at 10, 100, 500, and 1,500 people must complete within approved budgets and remain navigable.

## 8. Release Rule

Any mandatory failure blocks publication.
