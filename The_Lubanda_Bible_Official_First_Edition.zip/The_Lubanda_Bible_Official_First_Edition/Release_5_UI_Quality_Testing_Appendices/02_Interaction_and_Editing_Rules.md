---
title: "Interaction and Editing Rules"
document_code: "LNGP-R5-02"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Interaction and Editing Rules

**Document Code:** LNGP-R5-02  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Navigation

- pan with drag,
- zoom with wheel, pinch, and controls,
- fit tree,
- fit selection,
- return to root,
- search and focus.

## 2. Selection

Selectable:
- person,
- label,
- branch,
- lineage,
- territory,
- issue.

## 3. Dragging

Dragging is constraint-based:
- whole branch,
- single twig,
- label adjustment,
- free text.

Connectivity and collisions remain active.

## 4. Preview

Potentially disruptive changes show a preview and affected-region highlight.

## 5. Undo and Redo

All user changes must be undoable during the session.

## 6. Touch

Targets must be usable on tablets and foldable devices. Gestures must not conflict with page scrolling.

## 7. Search

Search supports normalized Arabic and direct ID lookup.

## 8. Inspector

The inspector distinguishes:
- source genealogy,
- derived metrics,
- geometry,
- style,
- diagnostics.

## 9. Locked Geometry

Administrators may lock accepted branches. The solver treats locks as constraints and reports impossibility rather than violating them silently.
