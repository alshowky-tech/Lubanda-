---
title: "Accessibility and Internationalization"
document_code: "LNGP-R5-03"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Accessibility and Internationalization

**Document Code:** LNGP-R5-03  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Language

Arabic is a first-class language. English and additional languages may coexist.

## 2. Direction

Support RTL and LTR interfaces, mixed-direction names, and locale-aware formatting.

## 3. Keyboard

All major operations should be keyboard accessible.

## 4. Screen Readers

Provide a semantic genealogy alternative to the visual canvas:
- person name,
- parent,
- children,
- generation,
- branch path.

## 5. Contrast

Text and controls must meet practical contrast requirements in screen and print profiles.

## 6. Motion

Animations should be subtle and reducible.

## 7. Text Scaling

UI text scaling must not make essential controls unusable.

## 8. Color Independence

Validation and status must not rely on color alone.

## 9. Export Accessibility

Where feasible, SVG/PDF exports should preserve text and logical metadata.
