---
title: "Release Checklist"
document_code: "LNGP-R5-10"
release: "Release 5 — UI, Quality, Testing & Appendices"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Release Checklist

**Document Code:** LNGP-R5-10  
**Release:** Release 5 — UI, Quality, Testing & Appendices  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Documentation
- [ ] Constitution and architecture remain consistent.
- [ ] Changed behavior is documented.
- [ ] Migration notes exist.
- [ ] Version numbers updated.

## Data
- [ ] Import tests pass.
- [ ] Validation tests pass.
- [ ] Arabic and mixed-text tests pass.
- [ ] Revision and rollback tests pass.

## Growth
- [ ] Zero forbidden crossings in official suites.
- [ ] Zero label overlaps.
- [ ] All paths connected.
- [ ] Deterministic seeds verified.
- [ ] Stability tests pass.

## Performance
- [ ] 10-person benchmark.
- [ ] 100-person benchmark.
- [ ] 500-person benchmark.
- [ ] 1,500-person benchmark.
- [ ] No unexplained regression.

## UI
- [ ] Mouse navigation.
- [ ] Touch navigation.
- [ ] Search.
- [ ] Undo/redo.
- [ ] RTL.
- [ ] Error navigation.

## Visual
- [ ] Bark preserves skeleton.
- [ ] Leaves represent terminal persons correctly.
- [ ] Style profile is readable.
- [ ] Template boundary respected.

## Export
- [ ] SVG verified.
- [ ] PNG verified.
- [ ] PDF verified.
- [ ] Arabic text verified.
- [ ] Large-format test completed.

## Security
- [ ] Upload validation.
- [ ] permissions.
- [ ] privacy review.
- [ ] secrets scan.

## Approval
- [ ] Automated suite passed.
- [ ] Manual structural review completed.
- [ ] Release owner approved.
