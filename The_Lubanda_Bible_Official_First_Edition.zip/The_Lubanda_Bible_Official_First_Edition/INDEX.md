# Documentation Index

## Releases

### Release 1 Foundation
- [01 Lubanda Constitution](Release_1_Foundation/01_Lubanda_Constitution.md)
- [02 Project Vision and Mission](Release_1_Foundation/02_Project_Vision_and_Mission.md)
- [03 Design Philosophy and Rule Zero](Release_1_Foundation/03_Design_Philosophy_and_Rule_Zero.md)
- [04 System Architecture](Release_1_Foundation/04_System_Architecture.md)
- [05 Decision Rules and Governance](Release_1_Foundation/05_Decision_Rules_and_Governance.md)
- [06 Roadmap and Phase Gates](Release_1_Foundation/06_Roadmap_and_Phase_Gates.md)

### Release 2 Data and Genealogy
- [01 Canonical Data Model](Release_2_Data_and_Genealogy/01_Canonical_Data_Model.md)
- [02 Excel Import Specification](Release_2_Data_and_Genealogy/02_Excel_Import_Specification.md)
- [03 Validation Engine](Release_2_Data_and_Genealogy/03_Validation_Engine.md)
- [04 Normalization and Arabic Text](Release_2_Data_and_Genealogy/04_Normalization_and_Arabic_Text.md)
- [05 Versioning and Change History](Release_2_Data_and_Genealogy/05_Versioning_and_Change_History.md)
- [06 Genealogy API Contracts](Release_2_Data_and_Genealogy/06_Genealogy_API_Contracts.md)

### Release 3 Growth Engine
- [01 Growth Engine Overview](Release_3_Growth_Engine/01_Growth_Engine_Overview.md)
- [02 Structural Weights and Demand](Release_3_Growth_Engine/02_Structural_Weights_and_Demand.md)
- [03 Territory Engine](Release_3_Growth_Engine/03_Territory_Engine.md)
- [04 Skeleton and Path Growth](Release_3_Growth_Engine/04_Skeleton_and_Path_Growth.md)
- [05 Collision Engine](Release_3_Growth_Engine/05_Collision_Engine.md)
- [06 Label Layout Engine](Release_3_Growth_Engine/06_Label_Layout_Engine.md)
- [07 Stability and Incremental Layout](Release_3_Growth_Engine/07_Stability_and_Incremental_Layout.md)
- [08 Performance and Scalability](Release_3_Growth_Engine/08_Performance_and_Scalability.md)
- [09 Growth Scoring and Acceptance](Release_3_Growth_Engine/09_Growth_Scoring_and_Acceptance.md)

### Release 4 AI and Visual System
- [01 AI Responsibilities and Boundaries](Release_4_AI_and_Visual_System/01_AI_Responsibilities_and_Boundaries.md)
- [02 Reference Style Analyzer](Release_4_AI_and_Visual_System/02_Reference_Style_Analyzer.md)
- [03 AI Growth Candidate Assistant](Release_4_AI_and_Visual_System/03_AI_Growth_Candidate_Assistant.md)
- [04 AI Visual Review](Release_4_AI_and_Visual_System/04_AI_Visual_Review.md)
- [05 Bark Rendering System](Release_4_AI_and_Visual_System/05_Bark_Rendering_System.md)
- [06 Leaves Ornaments and Templates](Release_4_AI_and_Visual_System/06_Leaves_Ornaments_and_Templates.md)
- [07 AI Administrator Assistant](Release_4_AI_and_Visual_System/07_AI_Administrator_Assistant.md)
- [08 Visual Profiles and Style Tokens](Release_4_AI_and_Visual_System/08_Visual_Profiles_and_Style_Tokens.md)

### Release 5 UI Quality Testing Appendices
- [01 UI Information Architecture](Release_5_UI_Quality_Testing_Appendices/01_UI_Information_Architecture.md)
- [02 Interaction and Editing Rules](Release_5_UI_Quality_Testing_Appendices/02_Interaction_and_Editing_Rules.md)
- [03 Accessibility and Internationalization](Release_5_UI_Quality_Testing_Appendices/03_Accessibility_and_Internationalization.md)
- [04 Engineering Standards](Release_5_UI_Quality_Testing_Appendices/04_Engineering_Standards.md)
- [05 Test Strategy](Release_5_UI_Quality_Testing_Appendices/05_Test_Strategy.md)
- [06 Acceptance Criteria](Release_5_UI_Quality_Testing_Appendices/06_Acceptance_Criteria.md)
- [07 Performance Benchmark Specification](Release_5_UI_Quality_Testing_Appendices/07_Performance_Benchmark_Specification.md)
- [08 Export and Print Specification](Release_5_UI_Quality_Testing_Appendices/08_Export_and_Print_Specification.md)
- [09 Security Privacy and Data Governance](Release_5_UI_Quality_Testing_Appendices/09_Security_Privacy_and_Data_Governance.md)
- [10 Release Checklist](Release_5_UI_Quality_Testing_Appendices/10_Release_Checklist.md)
- [11 Glossary](Release_5_UI_Quality_Testing_Appendices/11_Glossary.md)
- [12 Implementation Sequence](Release_5_UI_Quality_Testing_Appendices/12_Implementation_Sequence.md)
- [13 Master Prompt](Release_5_UI_Quality_Testing_Appendices/13_Master_Prompt.md)
