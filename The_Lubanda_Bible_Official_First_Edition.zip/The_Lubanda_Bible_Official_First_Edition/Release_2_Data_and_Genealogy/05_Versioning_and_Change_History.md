---
title: "Versioning and Change History"
document_code: "LNGP-R2-05"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Versioning and Change History

**Document Code:** LNGP-R2-05  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Project Versions

A genealogy project should maintain immutable revisions.

Each revision contains:
- revision ID,
- parent revision,
- timestamp,
- actor,
- operation summary,
- data checksum,
- validation result.

## 2. Change Operations

Preferred operation types:
- `PERSON_ADDED`
- `PERSON_UPDATED`
- `PARENT_CHANGED`
- `PERSON_REMOVED`
- `RECORD_RESTORED`
- `DUPLICATES_MERGED`
- `IMPORT_REPLACED`

## 3. Geometry Version Separation

Genealogy revision and geometry revision are separate. A style change must not create a genealogy revision.

## 4. Reproducible Layout

A saved layout records:
- genealogy revision,
- engine version,
- template version,
- settings,
- seed,
- manual constraints.

## 5. Conflict Handling

Concurrent edits should be detected at record or revision level. Parent changes require special review because they affect whole subtrees.

## 6. Rollback

Rollback must restore data and invalidate dependent geometry if necessary.

## 7. Import Replacement

Replacing an imported workbook should produce a diff:
- added,
- removed,
- updated,
- reparented,
- generation changed.

## 8. Preservation

Deleted records should be soft-deleted by default in managed projects so historical references remain auditable.
