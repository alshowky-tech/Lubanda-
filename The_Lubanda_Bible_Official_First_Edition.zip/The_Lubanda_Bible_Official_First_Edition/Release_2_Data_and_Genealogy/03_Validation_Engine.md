---
title: "Validation Engine"
document_code: "LNGP-R2-03"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Validation Engine

**Document Code:** LNGP-R2-03  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Purpose

The Validation Engine ensures that only structurally valid genealogy enters the growth pipeline.

## 2. Validation Order

1. File and schema checks
2. Row normalization
3. Required field checks
4. ID uniqueness
5. Parent existence
6. Self-parent checks
7. Root analysis
8. Cycle detection
9. Generation validation
10. Reachability
11. optional domain warnings

## 3. Issue Model

Each issue contains:
- code,
- severity,
- message,
- row number,
- person ID,
- related person ID,
- field,
- suggested resolution.

Severity:
- `fatal`
- `error`
- `warning`
- `info`

Rendering is blocked by fatal and error issues.

## 4. Required Issue Codes

- `EMPTY_FILE`
- `MISSING_COLUMN`
- `EMPTY_ID`
- `EMPTY_NAME`
- `DUPLICATE_ID`
- `SELF_PARENT`
- `MISSING_PARENT`
- `MULTIPLE_ROOTS`
- `NO_ROOT`
- `CYCLE`
- `GENERATION_MISMATCH`
- `UNREACHABLE_PERSON`
- `MALFORMED_VALUE`

## 5. Cycle Detection

Use depth-first color marking or topological analysis. Reports should include the cycle path, not merely state that a cycle exists.

## 6. Generation Validation

Default rule:
- root generation may be any configured baseline,
- each child must equal parent generation + 1.

Policies may permit unknown generation values, but inferred values must be marked as inferred.

## 7. Duplicate Names

Duplicate names are not genealogy errors. They should be warnings only and resolved by ID.

## 8. Repair Policy

Automatic repairs are limited to safe normalization:
- whitespace trimming,
- Unicode normalization,
- standard null conversion.

The engine must not automatically:
- choose a parent,
- merge people,
- invent IDs,
- alter generations,
- remove records.

## 9. Validation Output

The validator returns:
- normalized snapshot,
- issue list,
- statistics,
- root candidates,
- source checksum,
- validation version.

## 10. Acceptance

A snapshot is accepted only when:
- no blocking issues remain,
- a render root is resolved,
- all included persons are reachable,
- generation policy is satisfied.
