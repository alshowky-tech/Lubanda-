---
title: "Canonical Data Model"
document_code: "LNGP-R2-01"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Canonical Data Model

**Document Code:** LNGP-R2-01  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Person Record

Required:
- `id`: stable unique string
- `name`: display name
- `parentId`: direct parent ID or null for root
- `generation`: integer generation index

Optional:
- `title`
- `branchName`
- `birthPlace`
- `birthYear`
- `deathYear`
- `notes`
- `sourceRefs`
- `aliases`
- `status`
- `metadata`

## 2. Identity Rules

- IDs are not display values.
- IDs must remain stable when names change.
- IDs are case-normalized according to import policy.
- Leading and trailing whitespace is removed.
- Empty strings are converted to null only where allowed.
- Duplicate IDs are fatal.

## 3. Genealogy Graph

The canonical structure is a rooted directed acyclic graph constrained to one direct parent per person in the core tree model.

Derived indexes:
- person by ID,
- children by parent ID,
- root list,
- depth,
- ancestors,
- descendants,
- subtree size,
- terminal status,
- generation groups.

## 4. Root Semantics

A project may contain multiple disconnected roots during import, but rendering requires:
- one selected root, or
- an explicit multi-root composition mode.

Unintended multiple roots are validation errors.

## 5. Generation Semantics

Generation is a genealogical ordinal, not a visual level.

Recommended invariant:
`child.generation = parent.generation + 1`

Configured exceptions must be explicit and auditable.

## 6. Terminal Person

A terminal person has no included descendants in the selected rendered subtree. Terminal status is derived, not manually trusted.

Terminal persons may be rendered as leaves after structural approval.

## 7. Geometry Models

Separate records:
- `SkeletonNode`
- `SkeletonEdge`
- `BranchPath`
- `LabelAnchor`
- `Territory`
- `CollisionShape`
- `RenderStyle`

These records reference person IDs but never replace genealogy records.

## 8. Snapshot Model

Every solve uses an immutable `GenealogySnapshot` containing:
- schema version,
- project ID,
- selected root,
- normalized persons,
- validation summary,
- source checksum.

## 9. Auditability

Changes should be representable as operations:
- add person,
- update person,
- move parent,
- delete person,
- merge duplicate,
- restore person.

Operations require timestamps and actor identity where available.
