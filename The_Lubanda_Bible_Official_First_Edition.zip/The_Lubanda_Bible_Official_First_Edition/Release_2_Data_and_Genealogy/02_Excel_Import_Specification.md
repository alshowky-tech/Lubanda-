---
title: "Excel Import Specification"
document_code: "LNGP-R2-02"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Excel Import Specification

**Document Code:** LNGP-R2-02  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Supported Format

Primary format: `.xlsx`

One worksheet must contain the canonical genealogy table. The importer may allow worksheet selection.

## 2. Required Columns

Recommended Arabic headers:

- `كود الفرد الفريد (MANDATORY ID)`
- `الاسم الكامل للأبناء`
- `كود الأب المباشر (Parent ID)`
- `الجيل الموسوي المتسلسل`

Accepted aliases may be configured, but internal mapping must resolve to:
- `id`
- `name`
- `parentId`
- `generation`

## 3. Optional Columns

- title
- branch name
- birth place
- birth year
- death year
- notes
- source reference
- display order
- alias names

## 4. Cell Rules

- Formula cells should be read by computed value.
- Merged cells are prohibited in the data range.
- One person per row.
- Blank rows are ignored.
- Hidden rows are imported unless policy says otherwise.
- IDs must be treated as text to preserve leading zeros.
- Dates must not be guessed from ambiguous numeric values.
- Parent IDs must match normalized person IDs exactly.

## 5. Header Detection

The importer should:
1. inspect the first configurable number of rows,
2. score candidate header rows,
3. map known aliases,
4. request user confirmation when confidence is low.

## 6. Import Preview

Before committing, show:
- detected sheet,
- row count,
- mapped columns,
- roots,
- duplicates,
- missing parents,
- generation mismatches,
- ignored rows,
- warnings.

## 7. Fatal Errors

- missing required column,
- duplicate ID,
- empty ID,
- empty name,
- self-parent,
- missing referenced parent,
- cycle,
- impossible generation relation,
- unsupported structure.

## 8. Warnings

- unusual generation gap,
- duplicate name with different IDs,
- very long label,
- isolated optional metadata,
- suspicious numeric formatting,
- multiple roots.

## 9. Exported Correction File

The system should optionally produce an annotated workbook containing:
- original data,
- normalized values,
- issue code,
- issue severity,
- recommended correction.

## 10. Security

Spreadsheet imports must:
- ignore executable macros,
- avoid evaluating external links,
- limit file size,
- limit row and column counts,
- sanitize strings,
- process in a controlled environment.
