---
title: "Genealogy API Contracts"
document_code: "LNGP-R2-06"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Genealogy API Contracts

**Document Code:** LNGP-R2-06  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Contract Goals

APIs must be explicit, typed, deterministic, and independent of UI components.

## 2. Core Operations

- create project
- import snapshot
- validate snapshot
- select render root
- query person
- query ancestors
- query descendants
- update person
- change parent
- create revision
- compare revisions

## 3. Query Guarantees

Queries return canonical IDs and stable ordering where defined.

## 4. Error Contract

Errors include:
- stable code,
- human message,
- field path,
- related IDs,
- recoverability,
- optional remediation.

## 5. Mutation Rules

Mutations are rejected unless they preserve:
- unique IDs,
- valid parent reference,
- acyclic structure,
- generation policy.

## 6. Derived Data

Subtree size, terminal status, depth, and branch demand are derived values. They should not be accepted blindly from clients.

## 7. Security and Authorization

Administrative genealogy changes should be permission-controlled and auditable.

## 8. Transport Independence

Core contracts should not depend on HTTP, React, or a specific database.
