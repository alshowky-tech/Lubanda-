---
title: "Normalization and Arabic Text"
document_code: "LNGP-R2-04"
release: "Release 2 — Data & Genealogy"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Normalization and Arabic Text

**Document Code:** LNGP-R2-04  
**Release:** Release 2 — Data & Genealogy  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Principle

Normalization improves consistency without changing identity or meaning.

## 2. Unicode

Use Unicode normalization consistently. Preserve original text separately when normalized display differs.

## 3. Arabic Text

The platform must support:
- right-to-left direction,
- Arabic shaping,
- mixed Arabic and Latin IDs,
- Arabic numerals and Western numerals,
- diacritics,
- honorific policies,
- search without destructive display changes.

## 4. Name Policy

A project may define display rules such as removing a repeated honorific. The original name should remain available in source metadata.

## 5. Search Normalization

Search indexes may normalize:
- alef variants,
- ya/alef maqsura variants,
- optional diacritics,
- tatweel,
- whitespace.

Search normalization must not modify stored canonical names.

## 6. IDs

IDs should not undergo Arabic linguistic normalization. Only safe whitespace and Unicode normalization are allowed.

## 7. Numerals

Generation values and years should be parsed from supported Arabic-Indic and Western digit forms.

## 8. Bidirectional Safety

Mixed-direction labels must be tested in:
- web canvas,
- SVG,
- PNG export,
- PDF export,
- print.

## 9. Font Independence

The data model stores text, not font-specific outlines. Fonts belong to the presentation layer.

## 10. Audit

Every normalization step should be reproducible and versioned.
