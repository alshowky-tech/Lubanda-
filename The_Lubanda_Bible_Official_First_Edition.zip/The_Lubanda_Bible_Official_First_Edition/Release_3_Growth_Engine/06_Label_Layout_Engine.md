---
title: "Label Layout Engine"
document_code: "LNGP-R3-06"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Label Layout Engine

**Document Code:** LNGP-R3-06  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Purpose

Place person names and optional frames so each label is readable and clearly associated with the correct person.

## 2. Label Types

- wood label,
- branch label,
- terminal leaf label,
- decorative cartouche,
- free text element.

## 3. Measurement

Use actual typography metrics for the selected font, size, weight, and language.

## 4. Candidate Zones

Generate candidates near the person anchor:
- along branch,
- beside branch,
- above or below,
- terminal leaf position.

## 5. Association

The visual connection between label and person must be unambiguous. Long leader lines should be avoided.

## 6. Hard Constraints

- no overlap,
- no clipping,
- minimum font size,
- correct RTL layout,
- stable zoom behavior.

## 7. Soft Objectives

- consistent orientation,
- short anchor distance,
- balanced local density,
- avoidance of excessive rotation,
- aesthetic grouping.

## 8. Terminal Labels

People without descendants may use leaf forms. The leaf remains a label container, not a substitute for genealogy.

## 9. Search and Highlight

Labels should expose stable person IDs for search, focus, and navigation.

## 10. Export

Text may remain selectable in SVG/PDF where possible. Outline conversion is optional for print workflows.
