---
title: "Stability and Incremental Layout"
document_code: "LNGP-R3-07"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Stability and Incremental Layout

**Document Code:** LNGP-R3-07  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Stability Goal

Preserve the user's mental map and prior approved structure.

## 2. Incremental Cases

- add terminal child,
- add new sub-branch,
- rename person,
- change parent,
- remove person,
- change template,
- move whole branch,
- move one twig.

## 3. Anchor Classes

- fixed,
- strongly preferred,
- softly preferred,
- free.

## 4. Local Re-solve

The engine should first attempt:
1. affected node,
2. affected subtree,
3. local neighboring region,
4. major lineage,
5. full tree only as last resort.

## 5. Stability Cost

Candidate score should include movement cost relative to prior accepted geometry.

## 6. Manual Edits

Manual movement creates constraints, not destructive geometry. The engine must preserve connectivity and revalidate collisions.

## 7. Branch Movement

Moving a whole branch moves all descendants while maintaining local shape as much as possible.

## 8. Single Twig Movement

A single twig may be adjusted within a bounded range. The engine may alter nearby geometry to maintain clearance.

## 9. Parent Change

Changing parent invalidates the affected subtree's structural placement and may require a broader re-solve.

## 10. Acceptance

Unrelated branches should remain visually stable after local edits.
