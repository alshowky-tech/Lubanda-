---
title: "Territory Engine"
document_code: "LNGP-R3-03"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Territory Engine

**Document Code:** LNGP-R3-03  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Purpose

Provide each major lineage with an initial region in which to search for growth while preserving flexibility.

## 2. Territory Nature

A territory is:
- a planning region,
- a priority field,
- a congestion budget,
- not a rigid box.

## 3. Representation

Possible representations:
- polygon,
- weighted Voronoi cell,
- angular band,
- signed distance field,
- occupancy grid with lineage preference.

The contract should permit multiple implementations.

## 4. Allocation

Initial allocation should consider:
- subtree demand,
- trunk connection location,
- template shape,
- existing geometry,
- neighboring demand,
- desired canopy balance.

## 5. Negotiation

Territories may:
- expand,
- contract,
- rotate,
- exchange border space,
- reserve corridors.

Negotiation must remain deterministic.

## 6. Shared Space

When one lineage underuses its region, available space may be borrowed. Borrowing should preserve a readable visual distinction between major branches.

## 7. Failure Modes

- rigid wedge layouts,
- empty unusable gaps,
- territorial starvation,
- oscillating borders,
- equal share despite unequal demand.

## 8. Diagnostics

Show:
- territory polygons,
- demand values,
- occupied ratios,
- borrowed zones,
- blocked corridors.

## 9. Acceptance

Territory output is accepted when all major lineages have viable corridors and no branch is pre-forced into a collision.
