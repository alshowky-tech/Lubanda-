---
title: "Skeleton and Path Growth"
document_code: "LNGP-R3-04"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Skeleton and Path Growth

**Document Code:** LNGP-R3-04  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Skeleton Definition

The skeleton is a graph of centerlines and junctions representing wood structure before bark.

## 2. Trunk

The trunk:
- starts near the lower boundary,
- is longer than ordinary diagram stems,
- may contain selected ancestor labels,
- gradually narrows upward,
- provides attachment zones for primary lineages.

## 3. Branch Paths

Paths should use smooth curves such as cubic Bézier or spline representations.

## 4. Growth Step

A growth step evaluates:
- current tangent,
- target opportunity,
- obstacle gradient,
- territory preference,
- curvature limit,
- future branching demand.

## 5. Junctions

Junctions must:
- preserve continuity,
- avoid sharp forks,
- provide enough angular separation,
- reflect child demand,
- remain renderable as plausible wood.

## 6. Recursive Growth

Children should not all emerge from one point. Attachment positions may be distributed along a parent segment when genealogically and visually clear.

## 7. Direction Variation

Avoid repeated identical angles and lengths. Variation must be controlled, not random noise.

## 8. Path Simplification

After solving, simplify geometry without violating:
- clearance,
- curvature,
- anchor position,
- boundary,
- collision freedom.

## 9. Acceptance

Every person must have a continuous visual path to the selected root.
