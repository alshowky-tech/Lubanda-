---
title: "Growth Scoring and Acceptance"
document_code: "LNGP-R3-09"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Growth Scoring and Acceptance

**Document Code:** LNGP-R3-09  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Candidate Rejection

Reject immediately for:
- topology violation,
- crossing,
- disconnected path,
- boundary violation,
- unreadable label,
- excessive curvature,
- invalid junction.

## 2. Candidate Score

A valid candidate may be scored by:
- clearance,
- territory fit,
- curvature smoothness,
- stability,
- path efficiency,
- local density,
- canopy balance,
- future growth room,
- visual diversity.

## 3. Weighted Objectives

Weights must be configuration values and versioned. Hard constraints must never be simulated as merely high penalties.

## 4. Whole-Tree Metrics

- crossing count
- minimum clearance
- label overlap count
- disconnected count
- boundary violations
- occupied area ratio
- branch density variance
- movement from prior layout
- curvature distribution
- direction diversity

## 5. Acceptance Gate

Mandatory:
- zero forbidden crossings,
- zero label overlaps,
- all people connected,
- all labels readable,
- no fatal boundary violation.

## 6. Organic Review

After mandatory acceptance, evaluate:
- repeated angle patterns,
- artificial symmetry,
- excessive straightness,
- empty regions,
- compressed clusters,
- unnatural junctions.

## 7. Human Approval

For major official exports, the administrator may approve or request regeneration with preserved seed history.
