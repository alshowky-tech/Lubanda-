---
title: "Structural Weights and Demand"
document_code: "LNGP-R3-02"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Structural Weights and Demand

**Document Code:** LNGP-R3-02  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Purpose

Demand estimates how much geometric space a lineage requires.

## 2. Inputs

For each person or subtree:
- descendant count,
- maximum depth,
- branching factor,
- terminal count,
- label area,
- expected path width,
- optional importance weight.

## 3. Recommended Measures

- `subtreeSize`
- `terminalCount`
- `maxDepth`
- `branchEntropy`
- `labelDemand`
- `woodDemand`
- `totalDemand`

## 4. Demand Formula

The exact formula is configurable, but should:
- grow sublinearly with raw descendant count,
- account for width and label area,
- penalize deep narrow chains differently from broad shallow branches,
- avoid allowing one huge lineage to consume all space.

## 5. Use of Demand

Demand influences:
- initial territory share,
- branch thickness,
- path separation,
- label reserve,
- solver iteration budget,
- level of detail.

## 6. Dynamic Recalculation

Demand may be adjusted when:
- a branch cannot fit,
- label dimensions are measured,
- a template changes,
- a subtree is collapsed,
- prior geometry is reused.

## 7. Prohibition

Demand must not change genealogy order or omit people.
