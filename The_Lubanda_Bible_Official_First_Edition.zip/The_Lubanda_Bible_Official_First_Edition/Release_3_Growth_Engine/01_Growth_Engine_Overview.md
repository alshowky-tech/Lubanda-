---
title: "Growth Engine Overview"
document_code: "LNGP-R3-01"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Growth Engine Overview

**Document Code:** LNGP-R3-01  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Objective

Convert a validated genealogy subtree into a continuous, readable, collision-free, organic skeleton.

## 2. Input

- genealogy snapshot,
- selected root,
- template boundary,
- prior layout if any,
- growth configuration,
- deterministic seed.

## 3. Output

- skeleton graph,
- branch paths,
- widths,
- person anchors,
- label candidate zones,
- territories,
- diagnostics,
- acceptance metrics.

## 4. Major Stages

1. Compute structural demand.
2. Establish trunk.
3. Allocate initial lineage territories.
4. Grow primary branches.
5. Recursively grow descendants.
6. Resolve collisions.
7. place labels.
8. relax geometry.
9. validate.
10. freeze approved skeleton.

## 5. Hard Constraints

- topology matches genealogy,
- paths are connected,
- no forbidden crossings,
- clearances are respected,
- template boundary is respected where mandatory,
- labels are readable.

## 6. Soft Objectives

- organic curvature,
- balanced canopy,
- efficient space use,
- stable edits,
- varied directions,
- visual hierarchy,
- minimized path length.

## 7. Candidate-Based Solving

At each growth decision, generate multiple candidates and score them. A candidate violating a hard constraint is rejected before scoring.

## 8. Determinism

Random variation must be seed-driven and bounded by rules.

## 9. Debuggability

Every rejected candidate should optionally expose:
- rejection reason,
- collision pair,
- score components,
- sampled path,
- clearance failure.
