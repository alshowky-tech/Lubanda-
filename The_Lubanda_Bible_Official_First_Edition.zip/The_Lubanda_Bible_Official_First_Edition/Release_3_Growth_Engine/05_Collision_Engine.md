---
title: "Collision Engine"
document_code: "LNGP-R3-05"
release: "Release 3 — Growth Engine"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Collision Engine

**Document Code:** LNGP-R3-05  
**Release:** Release 3 — Growth Engine  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Collision Classes

- branch–branch
- branch–label
- label–label
- branch–boundary
- label–boundary
- branch–decoration
- self-intersection

## 2. Conservative Geometry

Use expanded collision shapes that include:
- stroke radius,
- bark allowance,
- safety margin,
- print tolerance.

## 3. Spatial Index

Recommended:
- spatial hash,
- R-tree,
- BVH,
- uniform grid.

The index must support incremental updates.

## 4. Segment Testing

Curves may be tested through:
- adaptive subdivision,
- capsule approximation,
- analytic methods where practical.

## 5. Continuous Safety

Checking only control points is insufficient. The full path must be tested.

## 6. Resolution Strategy

Preferred order:
1. reject candidate,
2. bend path,
3. shift junction,
4. adjust territory,
5. move label,
6. local relaxation,
7. escalate to regional re-solve.

## 7. Prohibited Resolution

- drawing one branch behind another,
- reducing opacity,
- hiding with bark,
- allowing collision at export,
- shrinking labels below readability.

## 8. Clearance Levels

Different element classes may use different minimum distances, but all must be configurable and testable.

## 9. Diagnostics

Collision reports should identify exact entities and closest points.
