---
title: "Reference Style Analyzer"
document_code: "LNGP-R4-02"
release: "Release 4 — AI & Visual System"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Reference Style Analyzer

**Document Code:** LNGP-R4-02  
**Release:** Release 4 — AI & Visual System  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Principle

Reference images are sources of growth philosophy, not templates to copy.

## 2. Extractable Properties

- branch curvature rhythm,
- trunk proportion,
- density,
- directional tendencies,
- junction softness,
- taper behavior,
- canopy occupancy,
- negative-space usage,
- bark character,
- leaf form,
- ornament style.

## 3. Prohibited Extraction

Do not reproduce:
- exact branch coordinates,
- exact label positions,
- unique artwork,
- copyrighted decorative composition,
- identity-specific content.

## 4. Output

A style profile should contain bounded parameters rather than pixels:
- curvature range,
- asymmetry level,
- density target,
- taper curve,
- branch angle distribution,
- texture family,
- ornament intensity.

## 5. Engine Control

Style parameters influence soft objectives only. They may not weaken hard constraints.

## 6. Confidence

Each extracted parameter should include confidence and source note.

## 7. Multiple References

When several references are supplied, the analyzer may:
- identify shared characteristics,
- expose differences,
- create named profiles,
- avoid averaging incompatible styles blindly.
