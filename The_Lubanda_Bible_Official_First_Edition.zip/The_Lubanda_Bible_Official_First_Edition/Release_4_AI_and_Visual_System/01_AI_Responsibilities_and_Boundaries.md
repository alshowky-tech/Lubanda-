---
title: "AI Responsibilities and Boundaries"
document_code: "LNGP-R4-01"
release: "Release 4 — AI & Visual System"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# AI Responsibilities and Boundaries

**Document Code:** LNGP-R4-01  
**Release:** Release 4 — AI & Visual System  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Golden Rule

> AI may suggest. Lubanda decides.

## 2. Allowed AI Roles

- reference style analysis,
- branch candidate suggestion,
- visual quality review,
- bark and texture rendering,
- template concept generation,
- natural-language administration,
- explanation and documentation assistance.

## 3. Forbidden AI Actions

AI must never:
- invent genealogy,
- change parent IDs,
- reorder generations,
- delete difficult people,
- move approved topology without engine approval,
- conceal collisions,
- bypass validation,
- modify source data silently.

## 4. Input Isolation

AI should receive only the minimum information required for its task.

## 5. Structured Output

AI suggestions should use typed structured output:
- candidate path,
- style parameters,
- review findings,
- command proposal.

Free text must not directly execute changes.

## 6. Validation

All AI outputs pass through:
- schema validation,
- security checks,
- genealogy protection,
- collision validation,
- policy validation.

## 7. Provenance

Record:
- model,
- prompt version,
- timestamp,
- input references,
- output checksum,
- acceptance status.

## 8. Failure

If AI is unavailable, the deterministic core platform must remain functional.
