---
title: "AI Growth Candidate Assistant"
document_code: "LNGP-R4-03"
release: "Release 4 — AI & Visual System"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# AI Growth Candidate Assistant

**Document Code:** LNGP-R4-03  
**Release:** Release 4 — AI & Visual System  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Purpose

Generate plausible branch trajectory candidates in difficult local regions.

## 2. Inputs

- local skeleton,
- obstacle map,
- target territory,
- current tangent,
- branch role,
- style profile,
- required clearances.

## 3. Output

Multiple candidate curves with confidence and rationale.

## 4. Restrictions

Candidates are advisory. The deterministic solver:
- checks topology,
- checks collisions,
- checks boundary,
- scores candidates,
- accepts or rejects.

## 5. No Direct Mutation

The AI never writes accepted geometry directly.

## 6. Fallback

If all candidates fail, the deterministic engine continues with its own search or escalates the region.

## 7. Learning Loop

Accepted and rejected results may improve prompts or models, but genealogy must never become training output without appropriate privacy and permission.
