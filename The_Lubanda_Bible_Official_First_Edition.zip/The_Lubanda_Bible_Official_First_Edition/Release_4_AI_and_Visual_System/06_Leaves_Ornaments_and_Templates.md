---
title: "Leaves, Ornaments, and Templates"
document_code: "LNGP-R4-06"
release: "Release 4 — AI & Visual System"
edition: "First Official Edition"
status: "Official"
language: "English"
project: "Lubanda Natural Genealogy Growth Platform"
---

# Leaves, Ornaments, and Templates

**Document Code:** LNGP-R4-06  
**Release:** Release 4 — AI & Visual System  
**Edition:** First Official Edition  
**Status:** Official

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Leaves

Leaves are primarily terminal-person label containers.

Rules:
- only terminal persons receive mandatory terminal leaves,
- leaves must not obscure branches,
- leaf size follows label demand,
- leaf orientation may vary naturally,
- leaf style is replaceable.

## 2. Ornament

Decorative elements may include:
- title frames,
- verses,
- cartouches,
- borders,
- knots,
- symbolic motifs.

They belong to the presentation layer.

## 3. Templates

Templates define available boundary and composition constraints, not branch paths.

Supported conceptual templates may include:
- circular,
- oval,
- teardrop,
- arch,
- rectangular mural,
- freeform polygon.

## 4. Template Change

Changing template triggers spatial re-solving but never changes genealogy.

## 5. Empty Space

Decorations must not occupy critical future growth corridors unless explicitly locked after completion.

## 6. Reference Use

Template and ornament references are analyzed for style, not copied mechanically.
