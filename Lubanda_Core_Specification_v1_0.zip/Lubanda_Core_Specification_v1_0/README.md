# Lubanda Core Specification v1.0

This package is the executable engineering specification for the **Lubanda Natural Genealogy Growth Platform**.

It translates the principles of *The Lubanda Bible* into concrete implementation contracts:

- module boundaries,
- domain types,
- interfaces,
- state machines,
- algorithm pipelines,
- pseudocode,
- configuration keys,
- diagnostics,
- error codes,
- testing obligations,
- file structure,
- implementation order.

## Normative Language

The terms **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are normative.

## Canonical Pipeline

`Import → Normalize → Validate → Build Genealogy Graph → Compute Demand → Allocate Territories → Grow Skeleton → Resolve Collisions → Place Labels → Validate Layout → Freeze Skeleton → Render Visuals → Export`

## Supreme Constraints

1. Genealogy MUST remain unchanged by layout and rendering.
2. Branches MUST NOT cross.
3. Labels MUST NOT overlap.
4. Every rendered person MUST have a continuous path to the selected root.
5. Generation MUST remain a data attribute, not a fixed screen coordinate.
6. AI output MUST remain advisory until deterministic validation accepts it.
7. Bark and decorative rendering MUST NOT change approved topology.
8. The same input snapshot, configuration, seed, and engine version MUST produce the same result.

## Package Structure

- `00_Governance`
- `01_Project_Architecture`
- `02_Domain_Model`
- `03_Engine_Contracts`
- `04_Algorithms`
- `05_Geometry_and_Collision`
- `06_Layout_and_Labels`
- `07_State_Persistence_and_API`
- `08_Diagnostics_and_Errors`
- `09_Testing_and_Benchmarks`
- `10_Implementation_Plan`
- `schemas`
- `examples`

## Intended Use

An engineer or AI coding assistant should be able to implement Lubanda module-by-module using this package without inventing architectural behavior.

The specification defines **what must be built and how modules must interact**. It does not prescribe one programming language, but TypeScript examples are used because the current project targets a modern TypeScript web stack.
