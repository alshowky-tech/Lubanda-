---
title: "Boundary and Template Constraints"
code: "LCS-GEO-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Geometry and Collision"
language: "English"
---

# Boundary and Template Constraints

**Specification Code:** `LCS-GEO-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Geometry and Collision

> Truth before beauty. Growth before drawing. Architecture before code.

---

## TemplateBoundary

```ts
type TemplateBoundary =
  | { kind: "POLYGON"; polygon: Polygon }
  | { kind: "ELLIPSE"; center: Vec2; rx: number; ry: number }
  | { kind: "ARCH"; parameters: ArchParameters }
  | { kind: "FREEFORM"; sdf: SignedDistanceField };
```

## Rules

- the trunk base may occupy a designated root zone,
- branches and labels must remain inside allowed regions,
- configured decorative reserve zones are obstacles,
- changing template triggers re-solve,
- the template does not prescribe branch routes.

## Boundary Clearance

Elements MUST remain inside by their full collision envelope, not only by centerline.
