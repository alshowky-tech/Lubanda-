---
title: "Spatial Index"
code: "LCS-GEO-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Geometry and Collision"
language: "English"
---

# Spatial Index

**Specification Code:** `LCS-GEO-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Geometry and Collision

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Reference Interface

```ts
interface SpatialIndex<T> {
  insert(id: string, bounds: Bounds, value: T): void;
  remove(id: string): void;
  update(id: string, bounds: Bounds): void;
  query(bounds: Bounds): readonly T[];
  clear(): void;
}
```

## Requirements

- deterministic query result ordering,
- incremental update,
- broad-phase collision support,
- configurable cell or node size,
- no hidden dependency on screen pixels.

## Reference Implementation

A uniform spatial hash is suitable for the first implementation. R-tree or BVH MAY replace it behind the same interface.
