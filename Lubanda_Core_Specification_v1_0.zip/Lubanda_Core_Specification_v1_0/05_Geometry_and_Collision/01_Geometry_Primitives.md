---
title: "Geometry Primitives"
code: "LCS-GEO-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Geometry and Collision"
language: "English"
---

# Geometry Primitives

**Specification Code:** `LCS-GEO-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Geometry and Collision

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Required Operations

- vector add/subtract/scale,
- dot and cross product,
- normalization,
- distance,
- point-segment distance,
- segment intersection,
- bounding box,
- polygon containment,
- curve evaluation,
- curve tangent,
- adaptive curve subdivision,
- curve length approximation.

## Numeric Tolerance

All geometry functions MUST use centrally configured epsilon values.

## Validation

NaN and infinite coordinates MUST be rejected immediately.

## Coordinate Range

The internal coordinate range SHOULD avoid floating-point instability at target tree sizes.
