---
title: "Collision Detection"
code: "LCS-GEO-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Geometry and Collision"
language: "English"
---

# Collision Detection

**Specification Code:** `LCS-GEO-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Geometry and Collision

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Broad Phase

Query spatial index using candidate envelope bounds.

## Narrow Phase

Use adaptive curve-to-curve distance or capsule chains.

## Collision Envelope Radius

```text
radius =
    branchHalfWidth
  + barkAllowance
  + classClearance
  + numericalSafetyMargin
```

## Adjacent Exemption

Parent-child connected edges may share geometry only within a bounded junction region.

## Self-Collision

A long curve MUST be tested against non-adjacent portions of itself.

## Exact Final Validation

Final validation SHOULD use a stricter sampling tolerance than interactive candidate testing.
