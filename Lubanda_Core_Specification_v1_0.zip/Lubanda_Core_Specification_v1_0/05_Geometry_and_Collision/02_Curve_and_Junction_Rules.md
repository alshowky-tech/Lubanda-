---
title: "Curve and Junction Rules"
code: "LCS-GEO-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Geometry and Collision"
language: "English"
---

# Curve and Junction Rules

**Specification Code:** `LCS-GEO-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Geometry and Collision

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Curves

Cubic Bézier curves are the reference representation.

## Curvature

Branches SHOULD:
- maintain tangent continuity,
- avoid abrupt sign changes,
- avoid excessive inflection count,
- preserve growth momentum.

## Junctions

A child branch:
- originates on the parent wood path,
- has a valid attachment parameter,
- begins with a tangent related to parent direction,
- has adequate angular separation,
- does not create a visible gap.

## Taper

Width MUST decrease monotonically overall from trunk to terminal stems, allowing only small local texture variation in the visual layer.
