---
title: "Demand and Territory Contracts"
code: "LCS-CON-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Demand and Territory Contracts

**Specification Code:** `LCS-CON-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface DemandEngine {
  compute(graph: GenealogyGraph, rootId: PersonId, ctx: SolveContext):
    ReadonlyMap<PersonId, SubtreeDemand>;
}

interface TerritorySolver {
  allocate(input: TerritorySolveInput, ctx: SolveContext): TerritoryPlan;
  negotiate(input: TerritoryNegotiationInput, ctx: SolveContext): TerritoryPlan;
}
```

## TerritorySolveInput

```ts
interface TerritorySolveInput {
  graph: GenealogyGraph;
  rootId: PersonId;
  demands: ReadonlyMap<PersonId, SubtreeDemand>;
  template: TemplateBoundary;
  trunk: PreliminaryTrunk;
  previousLayout?: ApprovedLayout;
}
```

## Contract Guarantees

A territory plan MUST:
- include all major lineage roots,
- remain inside allowed template regions,
- provide at least one viable corridor per lineage,
- report starvation rather than silently compressing below minimum demand.
