---
title: "Collision Contracts"
code: "LCS-CON-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Collision Contracts

**Specification Code:** `LCS-CON-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface CollisionEngine {
  index(graph: SkeletonGraph, labels?: readonly LabelPlacement[]): CollisionIndex;
  testCandidate(candidate: PathCandidate, index: CollisionIndex, policy: CollisionPolicy):
    CollisionTestResult;
  validateLayout(layout: LayoutResult, policy: CollisionPolicy):
    CollisionValidationReport;
}
```

## CollisionTestResult

```ts
type CollisionTestResult =
  | { valid: true; minimumClearance: number }
  | { valid: false; collisions: readonly CollisionRecord[] };
```

## CollisionRecord

MUST include:
- element IDs,
- collision class,
- closest points,
- penetration or clearance deficit,
- severity,
- recommended resolution scope.
