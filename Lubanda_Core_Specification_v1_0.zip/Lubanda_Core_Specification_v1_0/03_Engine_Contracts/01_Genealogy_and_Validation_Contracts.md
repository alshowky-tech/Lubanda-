---
title: "Genealogy and Validation Contracts"
code: "LCS-CON-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Genealogy and Validation Contracts

**Specification Code:** `LCS-CON-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface GenealogyImporter {
  importWorkbook(input: ArrayBuffer, options: ImportOptions): Promise<ImportPreview>;
  commit(preview: ImportPreview): Promise<GenealogySnapshot>;
}

interface GenealogyValidator {
  validate(snapshot: GenealogySnapshot, policy: ValidationPolicy): ValidationReport;
}

interface GenealogyGraphBuilder {
  build(snapshot: GenealogySnapshot): GenealogyGraph;
}
```

## ImportPreview

MUST include:
- sheet name,
- mapped columns,
- normalized row count,
- ignored rows,
- root candidates,
- issue list,
- source checksum.

## ValidationReport

```ts
interface ValidationReport {
  readonly accepted: boolean;
  readonly errors: readonly EngineIssue[];
  readonly warnings: readonly EngineIssue[];
  readonly statistics: GenealogyStatistics;
}
```

## Contract Rule

`commit` MUST NOT produce an accepted snapshot when blocking issues exist.
