---
title: "Visual and Export Contracts"
code: "LCS-CON-006"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Visual and Export Contracts

**Specification Code:** `LCS-CON-006`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface VisualRenderer {
  render(input: VisualRenderInput, ctx: RenderContext): Promise<VisualArtifact>;
}

interface ExportEngine {
  exportSvg(input: ExportInput): Promise<ExportArtifact>;
  exportPng(input: RasterExportInput): Promise<ExportArtifact>;
  exportPdf(input: PdfExportInput): Promise<ExportArtifact>;
}
```

## VisualRenderInput

MUST contain an immutable approved layout.

The renderer MUST NOT accept mutable genealogy services.

## Export Rule

Export engines MUST fail when the input layout is not approved, unless running in explicit diagnostic mode.
