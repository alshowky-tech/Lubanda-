---
title: "Skeleton Contracts"
code: "LCS-CON-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Skeleton Contracts

**Specification Code:** `LCS-CON-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface SkeletonEngine {
  createTrunk(input: TrunkInput, ctx: SolveContext): SkeletonFragment;
  growLineage(input: LineageGrowthInput, ctx: SolveContext): SkeletonFragment;
  merge(fragments: readonly SkeletonFragment[], ctx: SolveContext): SkeletonGraph;
}

interface PathCandidateGenerator {
  generate(input: CandidateRequest, ctx: SolveContext): readonly PathCandidate[];
}

interface PathScorer {
  score(candidate: PathCandidate, input: CandidateScoreInput): CandidateScore;
}
```

## Mandatory Candidate Fields

```ts
interface PathCandidate {
  readonly curve: CubicBezier;
  readonly targetAnchor: Vec2;
  readonly estimatedEnvelope: readonly Capsule[];
  readonly source: "DETERMINISTIC" | "AI_ADVISORY";
}
```

A candidate MUST be rejected before scoring when any hard constraint fails.
