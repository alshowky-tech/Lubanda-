---
title: "Label and Stability Contracts"
code: "LCS-CON-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# Label and Stability Contracts

**Specification Code:** `LCS-CON-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface TextMeasurementService {
  measure(request: TextMeasureRequest): TextMetricsResult;
}

interface LabelLayoutEngine {
  place(input: LabelLayoutInput, ctx: SolveContext): LabelLayoutResult;
}

interface IncrementalLayoutEngine {
  applyChange(input: IncrementalChangeInput, ctx: SolveContext): IncrementalLayoutResult;
}

interface ConstraintManager {
  add(constraint: ManualConstraint): ConstraintSet;
  remove(id: string): ConstraintSet;
  validate(set: ConstraintSet, graph: GenealogyGraph): ConstraintValidationReport;
}
```

## Stability Guarantee

The incremental engine SHOULD use the smallest valid re-solve scope:
1. node,
2. subtree,
3. neighboring region,
4. major lineage,
5. whole tree.
