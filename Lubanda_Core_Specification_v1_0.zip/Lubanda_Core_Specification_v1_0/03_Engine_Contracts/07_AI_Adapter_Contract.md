---
title: "AI Adapter Contract"
code: "LCS-CON-007"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Engine Contracts"
language: "English"
---

# AI Adapter Contract

**Specification Code:** `LCS-CON-007`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Engine Contracts

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface AIAdapter {
  analyzeStyle(request: StyleAnalysisRequest): Promise<StyleAnalysisResponse>;
  suggestPaths(request: PathSuggestionRequest): Promise<PathSuggestionResponse>;
  reviewLayout(request: LayoutReviewRequest): Promise<LayoutReviewResponse>;
  renderBark(request: BarkRenderRequest): Promise<BarkRenderResponse>;
}
```

## Mandatory Controls

- JSON schema validation
- timeout
- retry policy
- provenance logging
- privacy policy
- maximum payload size
- deterministic post-validation
- explicit user approval for sensitive external transmission

## Prohibition

AI responses MUST NOT be applied as mutations. They MUST first become typed proposals.
