---
title: "Decision Priority"
code: "LCS-GOV-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Governance"
language: "English"
---

# Decision Priority

**Specification Code:** `LCS-GOV-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Governance

> Truth before beauty. Growth before drawing. Architecture before code.

---

When objectives conflict, implementations MUST apply this priority:

1. Genealogical correctness
2. Parent-child readability
3. Collision avoidance
4. Structural continuity
5. Layout stability
6. Organic growth
7. Space utilization
8. Runtime performance
9. Visual beauty

A lower priority MUST NOT override a higher priority.

### Example

A shorter branch that crosses another branch is invalid even if it improves canopy balance.

A more attractive bark contour that covers a label is invalid.

A perfectly symmetric tree that misrepresents lineage size is invalid.

### Hard vs Soft Constraints

Hard constraints are pass/fail:
- valid topology,
- no forbidden crossing,
- no disconnected node,
- valid boundary rules,
- readable labels.

Soft objectives are scored:
- curvature naturalness,
- balanced density,
- territory fit,
- path efficiency,
- minimal movement,
- visual variety.
