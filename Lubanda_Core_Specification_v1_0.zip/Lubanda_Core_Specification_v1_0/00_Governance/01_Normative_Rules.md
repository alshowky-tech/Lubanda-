---
title: "Normative Rules"
code: "LCS-GOV-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Governance"
language: "English"
---

# Normative Rules

**Specification Code:** `LCS-GOV-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Governance

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Authority

This Core Specification is subordinate only to the Lubanda Constitution. If a conflict appears, the Constitution prevails.

## 2. Compliance Classes

### Mandatory
A requirement marked MUST or MUST NOT. Failure blocks release.

### Recommended
A requirement marked SHOULD or SHOULD NOT. Deviation requires an engineering decision record.

### Optional
A requirement marked MAY. It is permitted but not required.

## 3. Implementation Evidence

Every mandatory requirement MUST be supported by one or more of:
- automated test,
- benchmark,
- type contract,
- validation rule,
- diagnostic output,
- manual acceptance record.

## 4. Change Control

Any change to:
- public types,
- solver pipeline,
- hard constraints,
- persisted format,
- error codes,
- deterministic behavior

MUST increment the relevant specification version and provide migration notes.

## 5. Prohibited Interpretation

Implementers MUST NOT treat visual examples as permission to:
- change genealogy,
- hide crossings,
- use fixed radial charts,
- place all generations on horizontal layers,
- skip deterministic validation,
- allow renderers to mutate the skeleton.

## 6. Baseline Technology Assumptions

The reference implementation MAY use:
- TypeScript,
- React or Next.js,
- Web Workers,
- SVG and Canvas,
- IndexedDB or a server database,
- spatial indexes.

These are implementation choices, not constitutional requirements.

## 7. Definition of Done

A module is complete only when:
- its interface is implemented,
- tests pass,
- diagnostics exist,
- error behavior is defined,
- no hidden dependency violates architecture,
- its outputs satisfy downstream contracts.
