---
title: "State Machine"
code: "LCS-STA-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "State, Persistence, and API"
language: "English"
---

# State Machine

**Specification Code:** `LCS-STA-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** State, Persistence, and API

> Truth before beauty. Growth before drawing. Architecture before code.

---

```text
EMPTY
  └─ import → IMPORTED

IMPORTED
  ├─ validation failure → INVALID
  └─ validation success → READY_TO_SOLVE

INVALID
  └─ corrected import → IMPORTED

READY_TO_SOLVE
  └─ solve → SOLVING

SOLVING
  ├─ failure → LAYOUT_FAILED
  └─ success → LAYOUT_APPROVED

LAYOUT_FAILED
  └─ retry or configuration change → SOLVING

LAYOUT_APPROVED
  ├─ data change → READY_TO_SOLVE
  └─ render → RENDERING

RENDERING
  ├─ failure → LAYOUT_APPROVED
  └─ success → EXPORT_READY
```

Invalid transitions MUST return stable error codes.
