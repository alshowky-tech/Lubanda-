---
title: "Persistence Schema"
code: "LCS-STA-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "State, Persistence, and API"
language: "English"
---

# Persistence Schema

**Specification Code:** `LCS-STA-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** State, Persistence, and API

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Required Persistent Objects

- Project
- GenealogyRevision
- PersonRecord
- ValidationReport
- LayoutRevision
- ManualConstraint
- StyleProfile
- ExportRecord
- AuditEvent

## Separation

Genealogy revisions and layout revisions MUST be stored separately.

## Layout Metadata

A layout revision stores:
- genealogy revision ID,
- engine version,
- specification version,
- configuration checksum,
- seed,
- template version,
- previous layout reference,
- validation report,
- geometry payload.

## Migration

Persisted schemas MUST have explicit version numbers and migration functions.
