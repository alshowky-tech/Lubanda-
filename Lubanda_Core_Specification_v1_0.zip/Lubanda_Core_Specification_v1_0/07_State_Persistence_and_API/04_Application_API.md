---
title: "Application API"
code: "LCS-API-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "State, Persistence, and API"
language: "English"
---

# Application API

**Specification Code:** `LCS-API-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** State, Persistence, and API

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Example Service Surface

```ts
interface LubandaApplication {
  createProject(input: CreateProjectInput): Promise<ProjectState>;
  importGenealogy(projectId: ProjectId, file: ArrayBuffer): Promise<ImportPreview>;
  commitImport(projectId: ProjectId, previewId: string): Promise<GenealogySnapshot>;
  validateProject(projectId: ProjectId): Promise<ValidationReport>;
  solveLayout(projectId: ProjectId, request: LayoutRequest): Promise<SolveJob>;
  getSolveProgress(jobId: string): Promise<SolveProgress>;
  applyConstraint(projectId: ProjectId, constraint: ManualConstraint): Promise<ProjectState>;
  render(projectId: ProjectId, request: RenderRequest): Promise<VisualArtifact>;
  export(projectId: ProjectId, request: ExportRequest): Promise<ExportArtifact>;
}
```

## API Requirements

- authenticated where required,
- authorization by project role,
- idempotency for long-running job creation,
- explicit versioning,
- stable error payloads,
- no raw engine internals exposed accidentally.
