---
title: "Checkpoints and Recovery"
code: "LCS-STA-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "State, Persistence, and API"
language: "English"
---

# Checkpoints and Recovery

**Specification Code:** `LCS-STA-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** State, Persistence, and API

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Checkpoint Content

- solve ID,
- completed stage,
- immutable input references,
- partial skeleton,
- territory plan,
- random generator state,
- diagnostics summary.

## Recovery

A resumed solve MUST verify:
- same genealogy checksum,
- same configuration checksum,
- compatible engine version,
- compatible checkpoint version.

## Failure

An incompatible checkpoint MUST be rejected rather than partially reused.
