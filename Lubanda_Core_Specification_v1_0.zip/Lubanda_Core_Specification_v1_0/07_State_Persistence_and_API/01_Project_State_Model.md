---
title: "Project State Model"
code: "LCS-STA-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "State, Persistence, and API"
language: "English"
---

# Project State Model

**Specification Code:** `LCS-STA-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** State, Persistence, and API

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Project Aggregate

```ts
interface ProjectState {
  projectId: ProjectId;
  activeGenealogyRevisionId: RevisionId;
  activeLayoutId?: LayoutId;
  selectedRootId?: PersonId;
  templateId?: string;
  styleProfileId?: string;
  constraints: readonly ManualConstraint[];
  status: ProjectStatus;
}
```

## ProjectStatus

```text
EMPTY
IMPORTED
INVALID
READY_TO_SOLVE
SOLVING
LAYOUT_FAILED
LAYOUT_APPROVED
RENDERING
EXPORT_READY
```

## State Rule

Transitions MUST be explicit and validated.
