---
title: "Test Matrix"
code: "LCS-TST-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Testing and Benchmarks"
language: "English"
---

# Test Matrix

**Specification Code:** `LCS-TST-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Testing and Benchmarks

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Unit Tests

- ID normalization
- graph building
- cycle detection
- generation validation
- vector math
- curve sampling
- collision primitives
- label measurement cache
- score calculation

## Property Tests

Random valid genealogies MUST preserve:
- acyclicity,
- connectivity,
- one root in selected scope,
- deterministic solve replay.

## Integration Tests

- workbook to approved layout,
- local edit to incremental layout,
- approved layout to export,
- style change without geometry change.

## Visual Regression

Compare:
- skeleton debug SVG,
- territory view,
- label placement,
- final render separately.

## Failure Tests

Every error code SHOULD have at least one reproducing case.
