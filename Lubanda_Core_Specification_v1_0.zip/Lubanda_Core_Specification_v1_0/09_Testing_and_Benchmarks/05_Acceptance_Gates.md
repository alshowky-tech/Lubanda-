---
title: "Acceptance Gates"
code: "LCS-TST-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Testing and Benchmarks"
language: "English"
---

# Acceptance Gates

**Specification Code:** `LCS-TST-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Testing and Benchmarks

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Gate 1 — Data

No blocking genealogy issue.

## Gate 2 — Skeleton

All nodes connected; topology correct.

## Gate 3 — Geometry

Zero forbidden crossings and boundary violations.

## Gate 4 — Labels

Zero overlaps and minimum readability satisfied.

## Gate 5 — Stability

Incremental test changes stay within movement thresholds.

## Gate 6 — Determinism

Repeated fixed-seed runs serialize identically.

## Gate 7 — Performance

Official datasets complete within approved budgets.

## Gate 8 — Visual

Renderer preserves geometry and label visibility.

All eight gates are required for production release.
