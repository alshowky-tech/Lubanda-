---
title: "Official Test Datasets"
code: "LCS-TST-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Testing and Benchmarks"
language: "English"
---

# Official Test Datasets

**Specification Code:** `LCS-TST-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Testing and Benchmarks

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Dataset A — Minimal

1 root, 2 children, 3 generations.

## Dataset B — Deep Chain

100 people in one line.

## Dataset C — Wide Family

1 root with 50 direct descendants.

## Dataset D — Balanced

Approximately balanced branching to 500 people.

## Dataset E — Uneven Realistic

Two primary lineages with strongly unequal descendant counts.

## Dataset F — Maximum Target

Approximately 1,500 people and 10–13 generations.

## Dataset G — Arabic Stress

Long Arabic names, repeated names, mixed Arabic/Latin IDs.

## Dataset H — Incremental Edit

A stable layout with controlled additions, removals, and reparenting.

Each dataset MUST have:
- source file,
- expected validation result,
- expected person count,
- expected root,
- fixed seed,
- acceptance thresholds.
