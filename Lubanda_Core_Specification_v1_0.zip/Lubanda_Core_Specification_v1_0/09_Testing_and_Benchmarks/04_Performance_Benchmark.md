---
title: "Performance Benchmark"
code: "LCS-TST-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Testing and Benchmarks"
language: "English"
---

# Performance Benchmark

**Specification Code:** `LCS-TST-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Testing and Benchmarks

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Metrics

- import milliseconds,
- validation milliseconds,
- demand milliseconds,
- territory milliseconds,
- skeleton milliseconds,
- collision query count,
- label milliseconds,
- total solve milliseconds,
- peak memory,
- serialized layout size,
- interaction frame rate.

## Required Context

Record hardware, runtime, browser, build mode, engine version, seed, and dataset checksum.

## Regression Rule

A change that worsens runtime or memory by more than the project threshold MUST explain the quality or correctness benefit.

## Interaction Rule

Pan and zoom MUST remain responsive while solving occurs in a worker or separate execution context.
