---
title: "Layout Invariants"
code: "LCS-TST-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Testing and Benchmarks"
language: "English"
---

# Layout Invariants

**Specification Code:** `LCS-TST-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Testing and Benchmarks

> Truth before beauty. Growth before drawing. Architecture before code.

---

For every accepted layout:

1. Every included person appears exactly once.
2. Every non-root person has one visual parent path.
3. Every person reaches the selected root.
4. No forbidden branch crossing exists.
5. No label overlap exists.
6. Every label remains inside permitted bounds.
7. Every edge has finite coordinates.
8. Widths are positive.
9. Terminal leaves correspond only to terminal persons.
10. Same inputs reproduce identical serialized geometry.
