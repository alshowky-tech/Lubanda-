---
title: "Geometry Entities"
code: "LCS-DOM-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Domain Model"
language: "English"
---

# Geometry Entities

**Specification Code:** `LCS-DOM-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Domain Model

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Skeleton Node

```ts
type SkeletonNodeKind =
  | "TRUNK_BASE"
  | "PERSON_ANCHOR"
  | "JUNCTION"
  | "TERMINAL";

interface SkeletonNode {
  readonly id: string;
  readonly kind: SkeletonNodeKind;
  readonly position: Vec2;
  readonly personId?: PersonId;
  readonly fixed: boolean;
}
```

## Skeleton Edge

```ts
interface SkeletonEdge {
  readonly id: EdgeId;
  readonly branchId: BranchId;
  readonly parentNodeId: string;
  readonly childNodeId: string;
  readonly curve: CubicBezier;
  readonly startWidth: number;
  readonly endWidth: number;
  readonly personPath: readonly PersonId[];
}
```

## Cubic Bézier

```ts
interface CubicBezier {
  readonly p0: Vec2;
  readonly p1: Vec2;
  readonly p2: Vec2;
  readonly p3: Vec2;
}
```

## Branch

```ts
interface Branch {
  readonly id: BranchId;
  readonly lineageRootId: PersonId;
  readonly parentBranchId?: BranchId;
  readonly edgeIds: readonly EdgeId[];
  readonly order: number;
}
```

## Label Placement

```ts
interface LabelPlacement {
  readonly personId: PersonId;
  readonly bounds: Bounds;
  readonly anchor: Vec2;
  readonly rotation: number;
  readonly kind: "WOOD_NAME" | "TERMINAL_LEAF" | "CARTOUCHE";
}
```
