---
title: "Territory and Demand Entities"
code: "LCS-DOM-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Domain Model"
language: "English"
---

# Territory and Demand Entities

**Specification Code:** `LCS-DOM-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Domain Model

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Demand

```ts
interface SubtreeDemand {
  readonly personId: PersonId;
  readonly subtreeSize: number;
  readonly terminalCount: number;
  readonly maxDepth: number;
  readonly branchingFactor: number;
  readonly labelArea: number;
  readonly woodDemand: number;
  readonly totalDemand: number;
}
```

## Territory

```ts
interface Territory {
  readonly id: TerritoryId;
  readonly lineageRootId: PersonId;
  readonly polygon: Polygon;
  readonly preferredDirection: Vec2;
  readonly priority: number;
  readonly borrowedFrom?: readonly TerritoryId[];
}
```

## Occupancy

```ts
interface OccupancySample {
  readonly point: Vec2;
  readonly occupied: boolean;
  readonly ownerBranchId?: BranchId;
  readonly clearance: number;
}
```

Territories are preference regions and MUST NOT become hard rectangular cages unless the selected template explicitly requires it.
