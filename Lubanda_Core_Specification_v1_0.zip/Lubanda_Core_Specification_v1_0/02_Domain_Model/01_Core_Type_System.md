---
title: "Core Type System"
code: "LCS-DOM-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Domain Model"
language: "English"
---

# Core Type System

**Specification Code:** `LCS-DOM-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Domain Model

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Branded Identifiers

```ts
type Brand<T, B extends string> = T & { readonly __brand: B };

type PersonId = Brand<string, "PersonId">;
type ProjectId = Brand<string, "ProjectId">;
type RevisionId = Brand<string, "RevisionId">;
type LayoutId = Brand<string, "LayoutId">;
type EdgeId = Brand<string, "EdgeId">;
type BranchId = Brand<string, "BranchId">;
type TerritoryId = Brand<string, "TerritoryId">;
```

Branded IDs prevent accidental cross-assignment.

## Basic Geometry

```ts
interface Vec2 { x: number; y: number; }
interface Bounds { minX: number; minY: number; maxX: number; maxY: number; }
interface Circle { center: Vec2; radius: number; }
interface Capsule { a: Vec2; b: Vec2; radius: number; }
interface Polygon { points: readonly Vec2[]; }
```

## Units

Geometry MUST use one internal unit system. Rendering adapters convert to pixels, millimeters, or points.

## Immutability

Published domain values SHOULD be readonly.
