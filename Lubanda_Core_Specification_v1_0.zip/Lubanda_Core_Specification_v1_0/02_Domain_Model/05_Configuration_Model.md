---
title: "Configuration Model"
code: "LCS-DOM-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Domain Model"
language: "English"
---

# Configuration Model

**Specification Code:** `LCS-DOM-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Domain Model

> Truth before beauty. Growth before drawing. Architecture before code.

---

## EngineConfiguration

```ts
interface EngineConfiguration {
  readonly version: string;
  readonly geometry: GeometryConfig;
  readonly demand: DemandConfig;
  readonly territory: TerritoryConfig;
  readonly skeleton: SkeletonConfig;
  readonly collision: CollisionConfig;
  readonly labels: LabelConfig;
  readonly stability: StabilityConfig;
  readonly performance: PerformanceConfig;
}
```

## Configuration Rules

- All solver behavior that affects output MUST be versioned.
- Defaults MUST be explicit.
- Unknown keys MUST be rejected or safely ignored according to schema version.
- Configuration MUST be serializable.
- UI labels MUST map to configuration keys; UI components MUST NOT contain hidden solver constants.

## Example Key Families

```text
geometry.internalUnitsPerPixel
territory.maxNegotiationIterations
skeleton.maxCurvature
skeleton.candidateCount
collision.branchClearance
collision.labelClearance
labels.minimumFontSize
stability.priorLayoutWeight
performance.maxSolveMilliseconds
```
