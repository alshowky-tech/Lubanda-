---
title: "Genealogy Entities"
code: "LCS-DOM-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Domain Model"
language: "English"
---

# Genealogy Entities

**Specification Code:** `LCS-DOM-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Domain Model

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Person

```ts
interface Person {
  readonly id: PersonId;
  readonly name: string;
  readonly parentId: PersonId | null;
  readonly generation: number;
  readonly title?: string;
  readonly branchName?: string;
  readonly aliases?: readonly string[];
  readonly metadata?: Readonly<Record<string, unknown>>;
}
```

## GenealogySnapshot

```ts
interface GenealogySnapshot {
  readonly schemaVersion: string;
  readonly projectId: ProjectId;
  readonly revisionId: RevisionId;
  readonly persons: readonly Person[];
  readonly sourceChecksum: string;
  readonly createdAt: string;
}
```

## GenealogyGraph

```ts
interface GenealogyGraph {
  readonly personsById: ReadonlyMap<PersonId, Person>;
  readonly childrenByParentId: ReadonlyMap<PersonId, readonly PersonId[]>;
  readonly roots: readonly PersonId[];
  getAncestors(id: PersonId): readonly PersonId[];
  getDescendants(id: PersonId): readonly PersonId[];
  getSubtree(id: PersonId): readonly PersonId[];
}
```

## Invariants

- IDs are unique.
- One direct parent maximum.
- No cycles.
- Parent exists unless null.
- Rendered subtree has one selected root.
