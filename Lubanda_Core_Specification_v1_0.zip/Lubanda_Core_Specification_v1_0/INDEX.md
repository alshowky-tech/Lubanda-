# Lubanda Core Specification — Index

## 00 Governance
- [01 Normative Rules](00_Governance/01_Normative_Rules.md)
- [02 Decision Priority](00_Governance/02_Decision_Priority.md)
- [03 Traceability Matrix](00_Governance/03_Traceability_Matrix.md)

## 01 Project Architecture
- [01 Module Map](01_Project_Architecture/01_Module_Map.md)
- [02 Canonical Pipeline](01_Project_Architecture/02_Canonical_Pipeline.md)
- [03 Solve Coordinator](01_Project_Architecture/03_Solve_Coordinator.md)
- [04 Concurrency and Workers](01_Project_Architecture/04_Concurrency_and_Workers.md)

## 02 Domain Model
- [01 Core Type System](02_Domain_Model/01_Core_Type_System.md)
- [02 Genealogy Entities](02_Domain_Model/02_Genealogy_Entities.md)
- [03 Geometry Entities](02_Domain_Model/03_Geometry_Entities.md)
- [04 Territory and Demand Entities](02_Domain_Model/04_Territory_and_Demand_Entities.md)
- [05 Configuration Model](02_Domain_Model/05_Configuration_Model.md)

## 03 Engine Contracts
- [01 Genealogy and Validation Contracts](03_Engine_Contracts/01_Genealogy_and_Validation_Contracts.md)
- [02 Demand and Territory Contracts](03_Engine_Contracts/02_Demand_and_Territory_Contracts.md)
- [03 Skeleton Contracts](03_Engine_Contracts/03_Skeleton_Contracts.md)
- [04 Collision Contracts](03_Engine_Contracts/04_Collision_Contracts.md)
- [05 Label and Stability Contracts](03_Engine_Contracts/05_Label_and_Stability_Contracts.md)
- [06 Visual and Export Contracts](03_Engine_Contracts/06_Visual_and_Export_Contracts.md)
- [07 AI Adapter Contract](03_Engine_Contracts/07_AI_Adapter_Contract.md)

## 04 Algorithms
- [01 End to End Solve Pseudocode](04_Algorithms/01_End_to_End_Solve_Pseudocode.md)
- [02 Demand Computation](04_Algorithms/02_Demand_Computation.md)
- [03 Territory Allocation](04_Algorithms/03_Territory_Allocation.md)
- [04 Path Candidate Generation](04_Algorithms/04_Path_Candidate_Generation.md)
- [05 Candidate Rejection and Scoring](04_Algorithms/05_Candidate_Rejection_and_Scoring.md)
- [06 Recursive Lineage Growth](04_Algorithms/06_Recursive_Lineage_Growth.md)
- [07 Local Relaxation](04_Algorithms/07_Local_Relaxation.md)
- [08 Incremental Reflow](04_Algorithms/08_Incremental_Reflow.md)

## 05 Geometry and Collision
- [01 Geometry Primitives](05_Geometry_and_Collision/01_Geometry_Primitives.md)
- [02 Curve and Junction Rules](05_Geometry_and_Collision/02_Curve_and_Junction_Rules.md)
- [03 Spatial Index](05_Geometry_and_Collision/03_Spatial_Index.md)
- [04 Collision Detection](05_Geometry_and_Collision/04_Collision_Detection.md)
- [05 Boundary and Template Constraints](05_Geometry_and_Collision/05_Boundary_and_Template_Constraints.md)

## 06 Layout and Labels
- [01 Text Measurement](06_Layout_and_Labels/01_Text_Measurement.md)
- [02 Label Candidate Generation](06_Layout_and_Labels/02_Label_Candidate_Generation.md)
- [03 Label Solver](06_Layout_and_Labels/03_Label_Solver.md)
- [04 Canopy Utilization](06_Layout_and_Labels/04_Canopy_Utilization.md)

## 07 State Persistence and API
- [01 Project State Model](07_State_Persistence_and_API/01_Project_State_Model.md)
- [02 State Machine](07_State_Persistence_and_API/02_State_Machine.md)
- [03 Persistence Schema](07_State_Persistence_and_API/03_Persistence_Schema.md)
- [04 Application API](07_State_Persistence_and_API/04_Application_API.md)
- [05 Checkpoints and Recovery](07_State_Persistence_and_API/05_Checkpoints_and_Recovery.md)

## 08 Diagnostics and Errors
- [01 Error Catalog](08_Diagnostics_and_Errors/01_Error_Catalog.md)
- [02 Diagnostic Event Model](08_Diagnostics_and_Errors/02_Diagnostic_Event_Model.md)
- [03 Debug Visualizations](08_Diagnostics_and_Errors/03_Debug_Visualizations.md)

## 09 Testing and Benchmarks
- [01 Test Matrix](09_Testing_and_Benchmarks/01_Test_Matrix.md)
- [02 Official Datasets](09_Testing_and_Benchmarks/02_Official_Datasets.md)
- [03 Layout Invariants](09_Testing_and_Benchmarks/03_Layout_Invariants.md)
- [04 Performance Benchmark](09_Testing_and_Benchmarks/04_Performance_Benchmark.md)
- [05 Acceptance Gates](09_Testing_and_Benchmarks/05_Acceptance_Gates.md)

## 10 Implementation Plan
- [01 Repository Structure](10_Implementation_Plan/01_Repository_Structure.md)
- [02 Build Order](10_Implementation_Plan/02_Build_Order.md)
- [03 First 90 Day Plan](10_Implementation_Plan/03_First_90_Day_Plan.md)
- [04 AI Coding Assistant Workflow](10_Implementation_Plan/04_AI_Coding_Assistant_Workflow.md)
- [05 Release Definition](10_Implementation_Plan/05_Release_Definition.md)

## Schemas
- `schemas/engine-configuration.schema.json`
- `schemas/person.schema.json`
- `schemas/error-codes.json`

## Examples
- `examples/default-engine-configuration.json`
- `examples/sample-types.ts`
