---
title: "Path Candidate Generation"
code: "LCS-ALG-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Path Candidate Generation

**Specification Code:** `LCS-ALG-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Candidate Inputs

- start position,
- start tangent,
- target opportunity field,
- branch thickness,
- remaining subtree demand,
- obstacle distance field,
- territory preference,
- prior geometry.

## Candidate Families

1. direct smooth curve,
2. lateral arc,
3. upward opening curve,
4. downward then outward curve,
5. corridor-following curve,
6. prior-layout-preserving curve,
7. AI advisory curve.

## Pseudocode

```text
function GENERATE_CANDIDATES(request):
    directions = sampleDirectionsAroundPreferredVector(
        request.startTangent,
        request.maxTurnAngle,
        request.sampleCount
    )

    candidates = []
    for direction in directions:
        endpoint = searchOpportunity(direction, request.territory, request.obstacles)
        controls = createBezierControls(
            start=request.start,
            startTangent=request.startTangent,
            endpoint=endpoint,
            endTangent=estimateFreeSpaceDirection(endpoint)
        )
        candidates.append(bezier(controls))

    return deduplicateAndSimplify(candidates)
```

## Requirements

Candidates MUST honor curvature and minimum segment length before collision testing.
