---
title: "End-to-End Solve Pseudocode"
code: "LCS-ALG-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# End-to-End Solve Pseudocode

**Specification Code:** `LCS-ALG-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

```text
function SOLVE(request):
    validateRequestShape(request)

    validation = GenealogyValidator.validate(request.snapshot)
    if validation.hasBlockingIssues:
        return failure(validation.issues)

    graph = GenealogyGraphBuilder.build(request.snapshot)
    scope = graph.getSubtree(request.selectedRootId)

    demands = DemandEngine.compute(graph, request.selectedRootId)

    trunk = SkeletonEngine.createTrunk(
        root = request.selectedRootId,
        template = request.template,
        demand = demands[root]
    )

    territories = TerritorySolver.allocate(
        graph, demands, request.template, trunk, request.previousLayout
    )

    fragments = [trunk]

    for lineageRoot in orderedPrimaryLineages(graph, root):
        fragment = GROW_LINEAGE(lineageRoot, territories[lineageRoot], context)
        if fragment.failed:
            territories = TerritorySolver.negotiate(fragment.failureContext)
            fragment = GROW_LINEAGE(lineageRoot, territories[lineageRoot], context)
        if fragment.failed:
            return failure(fragment.issues)
        fragments.append(fragment)

    skeleton = SkeletonEngine.merge(fragments)
    skeleton = CollisionResolver.resolve(skeleton)

    labels = LabelLayoutEngine.place(skeleton, graph)
    layout = LocalRelaxation.optimize(skeleton, labels)

    report = LayoutValidator.validate(layout)
    if not report.accepted:
        return failure(report.issues)

    approved = freezeLayout(layout, request)
    return success(approved)
```
