---
title: "Incremental Reflow"
code: "LCS-ALG-008"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Incremental Reflow

**Specification Code:** `LCS-ALG-008`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Change Classification

- `LABEL_ONLY`
- `ADD_TERMINAL`
- `ADD_SUBTREE`
- `REMOVE_TERMINAL`
- `REMOVE_SUBTREE`
- `REPARENT_SUBTREE`
- `TEMPLATE_CHANGE`
- `MANUAL_BRANCH_MOVE`

## Reflow Scope

```text
function DETERMINE_REFLOW_SCOPE(change):
    if LABEL_ONLY:
        return label neighborhood
    if ADD_TERMINAL or REMOVE_TERMINAL:
        return parent subtree + adjacent clearance region
    if ADD_SUBTREE:
        return affected lineage
    if REPARENT_SUBTREE:
        return old lineage + new lineage + trunk attachment region
    if TEMPLATE_CHANGE:
        return full tree
```

## Stability Objective

Existing accepted geometry receives soft positional and directional constraints.

## Acceptance

Unrelated lineages SHOULD remain within configured movement tolerance.
