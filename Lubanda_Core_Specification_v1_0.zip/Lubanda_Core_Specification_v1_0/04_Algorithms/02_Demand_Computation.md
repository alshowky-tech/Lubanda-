---
title: "Demand Computation"
code: "LCS-ALG-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Demand Computation

**Specification Code:** `LCS-ALG-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Required Derived Values

For each person:
- subtree size,
- terminal descendant count,
- maximum depth,
- immediate child count,
- estimated label area,
- structural branching complexity.

## Reference Formula

```text
woodDemand =
    a * sqrt(subtreeSize)
  + b * terminalCount
  + c * maxDepth
  + d * branchEntropy

labelDemand =
    sum(estimatedLabelArea for subtree) ^ 0.5

totalDemand =
    clamp(woodDemand + labelWeight * labelDemand, minDemand, maxDemand)
```

Exact coefficients are configuration values.

## Pseudocode

```text
function COMPUTE_DEMAND(node):
    if node has no children:
        return terminal demand

    childDemands = map(COMPUTE_DEMAND, children(node))

    subtreeSize = 1 + sum(child.subtreeSize)
    terminalCount = sum(child.terminalCount)
    maxDepth = 1 + max(child.maxDepth)
    branchEntropy = entropy(normalize(child.totalDemand))

    return composeDemand(...)
```

## Requirement

Demand MUST be computed bottom-up.
