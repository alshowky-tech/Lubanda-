---
title: "Candidate Rejection and Scoring"
code: "LCS-ALG-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Candidate Rejection and Scoring

**Specification Code:** `LCS-ALG-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Hard Rejection

Reject when:
- topology invalid,
- curve self-intersects,
- collision envelope intersects forbidden geometry,
- endpoint outside allowed boundary,
- curvature exceeds limit,
- junction angle below minimum,
- no future space remains for required descendants.

## Score Components

```text
score =
    + wClearance * normalizedClearance
    + wTerritory * territoryFit
    + wFuture * futureGrowthRoom
    + wOrganic * curvatureNaturalness
    + wStability * priorLayoutSimilarity
    + wBalance * localDensityBalance
    - wLength * excessiveLength
    - wTurn * directionalDiscontinuity
```

## Deterministic Tie-Breaking

Tie-break by:
1. higher clearance,
2. greater future room,
3. lower movement,
4. lexicographic candidate key.

Random tie-breaking is prohibited.
