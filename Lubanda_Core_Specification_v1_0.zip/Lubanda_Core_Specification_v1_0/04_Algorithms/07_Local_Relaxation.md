---
title: "Local Relaxation"
code: "LCS-ALG-007"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Local Relaxation

**Specification Code:** `LCS-ALG-007`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Purpose

Improve spacing and naturalness after a valid initial layout.

## Allowed Variables

- control points,
- junction positions,
- label positions,
- territory borders,
- branch angles within limits.

## Locked Variables

- genealogy topology,
- selected root,
- fixed anchors,
- user locks,
- approved branch identity.

## Iterative Process

```text
repeat until convergence or maxIterations:
    compute forces:
        repulsion from collision envelopes
        attraction to territory center
        smoothness force
        stability force
        boundary force
        label separation force

    propose bounded movements
    reject any movement violating hard constraints
    apply accepted movements
```

## Convergence

Stop when:
- maximum movement below threshold,
- score improvement below threshold,
- iteration limit reached.

A non-converged but valid layout MAY be accepted with warning.
