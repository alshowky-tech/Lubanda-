---
title: "Territory Allocation"
code: "LCS-ALG-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Territory Allocation

**Specification Code:** `LCS-ALG-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Reference Strategy

Use weighted angular or polygonal partitioning followed by relaxation.

```text
function ALLOCATE_TERRITORIES(primaryLineages, template, demands):
    seeds = initializeSeedsAroundTrunk(primaryLineages, demands)
    regions = weightedVoronoi(template, seeds, demands)

    repeat until converged or iterationLimit:
        for each lineage:
            occupancy = estimateUsableArea(regions[lineage])
            deficit = requiredArea(demand[lineage]) - occupancy
            moveSeedAlongFreeSpaceGradient(lineage, deficit)
        regions = weightedVoronoi(template, seeds, demands)

    return regions
```

## Negotiation

When a lineage fails:
1. identify blocking neighbors,
2. identify underused adjacent space,
3. reserve corridor,
4. shift shared boundary,
5. retry affected lineages only.

## Forbidden Result

A lineage territory with no path from trunk attachment to usable interior is invalid.
