---
title: "Recursive Lineage Growth"
code: "LCS-ALG-006"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Algorithms"
language: "English"
---

# Recursive Lineage Growth

**Specification Code:** `LCS-ALG-006`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Algorithms

> Truth before beauty. Growth before drawing. Architecture before code.

---

```text
function GROW_LINEAGE(person, anchor, territory):
    create person anchor at anchor

    children = orderChildrenByDemandAndStability(person.children)

    if children is empty:
        reserveTerminalLabelZone(person)
        return

    attachmentSites = distributeAttachmentSites(
        parentPath,
        children,
        childDemands
    )

    for child in children:
        request = buildCandidateRequest(child, attachmentSites[child], territory)
        candidates = generateCandidates(request)

        valid = []
        for candidate in candidates:
            if passesHardConstraints(candidate):
                valid.append(score(candidate))

        if valid is empty:
            result = attemptLocalRepair(child)
            if result failed:
                return lineageFailure(child)

        accepted = best(valid)
        commitPath(accepted)
        GROW_LINEAGE(child, accepted.targetAnchor, childTerritory(child))
```

## Child Ordering

Ordering SHOULD prioritize:
- constrained children first,
- larger demand,
- prior stable placement,
- deeper descendants,
- then stable ID order.
