---
title: "Solve Coordinator"
code: "LCS-ARC-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Project Architecture"
language: "English"
---

# Solve Coordinator

**Specification Code:** `LCS-ARC-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Project Architecture

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Responsibility

`SolveCoordinator` orchestrates the complete deterministic layout solve.

## Interface

```ts
interface SolveCoordinator {
  solve(request: SolveRequest, signal?: AbortSignal): Promise<SolveResult>;
  resume(checkpoint: SolveCheckpoint, signal?: AbortSignal): Promise<SolveResult>;
  validate(result: LayoutResult): Promise<LayoutValidationReport>;
}
```

## SolveRequest

```ts
interface SolveRequest {
  snapshot: GenealogySnapshot;
  selectedRootId: PersonId;
  template: TemplateBoundary;
  configuration: EngineConfiguration;
  seed: number;
  previousLayout?: ApprovedLayout;
  constraints?: ManualConstraint[];
}
```

## Required Behavior

The coordinator MUST:
- validate inputs before solving,
- preserve stage order,
- emit progress,
- support cancellation,
- record timings,
- create checkpoints for long solves,
- return deterministic output,
- never accept an invalid final layout.

## Progress Events

```ts
interface SolveProgress {
  stage: SolveStage;
  completedUnits: number;
  totalUnits?: number;
  percent?: number;
  messageKey: string;
}
```
