---
title: "Module Map"
code: "LCS-ARC-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Project Architecture"
language: "English"
---

# Module Map

**Specification Code:** `LCS-ARC-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Project Architecture

> Truth before beauty. Growth before drawing. Architecture before code.

---

## 1. Top-Level Modules

```text
core/
  genealogy/
  validation/
  geometry/
  spatial/
  demand/
  territory/
  skeleton/
  collision/
  labels/
  stability/
  solve/
  diagnostics/
  persistence/
  export/
  ai/
  visual/
ui/
workers/
tests/
```

## 2. Dependency Direction

```text
genealogy ──► validation
geometry ───► spatial
genealogy ──► demand
demand ─────► territory
territory ──► skeleton
geometry ───► skeleton
spatial ────► collision
skeleton ───► collision
collision ──► labels
skeleton ───► labels
all engines ─► diagnostics
solve ──────► engine orchestration
visual ─────► approved skeleton only
export ─────► approved layout + visual output
ui ─────────► public application services only
```

## 3. Dependency Prohibitions

- `visual` MUST NOT import genealogy mutation services.
- `ui` MUST NOT directly mutate core engine collections.
- `collision` MUST NOT modify source genealogy.
- `export` MUST NOT repair layout defects.
- `ai` MUST NOT bypass typed adapters.
- engine modules MUST NOT depend on React components.

## 4. Public Boundary

The UI communicates through application services:
- `ProjectService`
- `ImportService`
- `ValidationService`
- `LayoutService`
- `EditConstraintService`
- `StyleService`
- `ExportService`

## 5. Internal Boundary

Internal data structures MAY be optimized, but public result objects MUST remain versioned and serializable.
