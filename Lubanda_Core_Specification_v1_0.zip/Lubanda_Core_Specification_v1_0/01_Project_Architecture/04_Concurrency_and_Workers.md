---
title: "Concurrency and Workers"
code: "LCS-ARC-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Project Architecture"
language: "English"
---

# Concurrency and Workers

**Specification Code:** `LCS-ARC-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Project Architecture

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Principle

Long-running solves MUST NOT block navigation or core UI interaction.

## Worker Candidates

- import parsing,
- validation,
- demand computation,
- territory solving,
- skeleton candidate generation,
- collision broad phase,
- raster export.

## Determinism

Parallel execution MUST preserve deterministic reduction order.

## Message Contracts

Worker messages MUST be:
- serializable,
- versioned,
- immutable,
- cancellable,
- traceable by solve ID.

## Shared Memory

Shared memory MAY be used for performance only when:
- race behavior is controlled,
- tests prove determinism,
- fallbacks exist.

## Cancellation

Every iterative engine SHOULD check cancellation at bounded intervals.
