---
title: "Canonical Pipeline"
code: "LCS-ARC-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Project Architecture"
language: "English"
---

# Canonical Pipeline

**Specification Code:** `LCS-ARC-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Project Architecture

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Pipeline Stages

### Stage 0 — Acquire
Read file or project revision.

### Stage 1 — Normalize
Normalize safe textual and numeric representations.

### Stage 2 — Validate
Produce blocking errors and warnings.

### Stage 3 — Build Graph
Build immutable genealogy indexes.

### Stage 4 — Select Scope
Resolve selected root and included descendants.

### Stage 5 — Compute Demand
Calculate subtree spatial demand.

### Stage 6 — Plan Territories
Allocate flexible lineage preference regions.

### Stage 7 — Grow Skeleton
Generate trunk, branches, twigs, and anchors.

### Stage 8 — Resolve Geometry
Detect and resolve collisions and boundary violations.

### Stage 9 — Place Labels
Measure and place labels.

### Stage 10 — Relax
Improve local geometry while maintaining all hard constraints.

### Stage 11 — Validate Layout
Run final exact checks.

### Stage 12 — Freeze
Create immutable approved skeleton revision.

### Stage 13 — Render
Apply bark, leaves, typography, and decoration.

### Stage 14 — Export
Create SVG, PNG, PDF, or interactive artifact.

## Stage Contract

Each stage MUST return:

```ts
type StageResult<T> =
  | { ok: true; value: T; diagnostics: DiagnosticEvent[] }
  | { ok: false; errors: EngineIssue[]; diagnostics: DiagnosticEvent[] };
```

Stages MUST NOT silently continue after blocking failure.
