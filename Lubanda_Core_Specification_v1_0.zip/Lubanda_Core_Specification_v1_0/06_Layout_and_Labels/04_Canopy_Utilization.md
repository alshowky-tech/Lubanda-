---
title: "Canopy Utilization"
code: "LCS-LAY-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Layout and Labels"
language: "English"
---

# Canopy Utilization

**Specification Code:** `LCS-LAY-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Layout and Labels

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Objective

Use available space without creating artificial uniform filling.

## Metrics

- occupied area ratio,
- empty region size distribution,
- lineage density variance,
- minimum clearance,
- distance from template boundary,
- centroid balance.

## Rules

- empty space is not automatically a defect,
- large avoidable gaps are defects,
- reducing the template MUST trigger re-layout rather than uniform scaling,
- the tree SHOULD seek new free regions while preserving readable separation.

## Prohibition

The engine MUST NOT shrink the whole tree merely because the template becomes smaller unless explicit scale mode is selected.
