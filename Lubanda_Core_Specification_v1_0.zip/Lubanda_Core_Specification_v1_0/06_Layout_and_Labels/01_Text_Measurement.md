---
title: "Text Measurement"
code: "LCS-LBL-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Layout and Labels"
language: "English"
---

# Text Measurement

**Specification Code:** `LCS-LBL-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Layout and Labels

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Inputs

- text,
- font family,
- font size,
- font weight,
- letter spacing,
- direction,
- maximum width,
- line count policy.

## Outputs

- width,
- height,
- baseline,
- line boxes,
- glyph overflow if available.

## Requirements

- Arabic shaping support,
- RTL and mixed-direction testing,
- deterministic measurement for export,
- fallback font policy,
- cache keyed by full typography request.

## Prohibition

Approximate character-count sizing MUST NOT be used for final placement.
