---
title: "Label Solver"
code: "LCS-LBL-003"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Layout and Labels"
language: "English"
---

# Label Solver

**Specification Code:** `LCS-LBL-003`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Layout and Labels

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Reference Strategy

Use ordered candidate assignment with backtracking for congested regions.

```text
sort labels by difficulty:
    fewest candidates,
    largest area,
    highest local density,
    stable prior label first

for label in labels:
    choose best non-colliding candidate
    if none:
        backtrack local assignments
    if still none:
        request local geometry relaxation
    if still none:
        fail with LABEL_PLACEMENT_IMPOSSIBLE
```

## Hard Rules

- no overlap,
- minimum font size,
- complete text visibility,
- correct person association,
- no crossing leader lines.

## Output

The solver MUST expose unresolved candidate reasons.
