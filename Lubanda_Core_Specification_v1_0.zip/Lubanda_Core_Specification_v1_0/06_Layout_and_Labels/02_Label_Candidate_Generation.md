---
title: "Label Candidate Generation"
code: "LCS-LBL-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Layout and Labels"
language: "English"
---

# Label Candidate Generation

**Specification Code:** `LCS-LBL-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Layout and Labels

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Candidate Families

- aligned with branch,
- offset above branch,
- offset below branch,
- lateral,
- terminal leaf,
- cartouche zone.

## Candidate Fields

```ts
interface LabelCandidate {
  personId: PersonId;
  bounds: Bounds;
  anchor: Vec2;
  rotation: number;
  leaderLength: number;
  class: string;
}
```

## Scoring

Prefer:
- no collision,
- short anchor distance,
- low rotation,
- consistent local rhythm,
- stable prior location,
- adequate branch clearance.

## Terminal Person

A terminal leaf label MAY be larger than ordinary branch labels but MUST remain within boundary and collision rules.
