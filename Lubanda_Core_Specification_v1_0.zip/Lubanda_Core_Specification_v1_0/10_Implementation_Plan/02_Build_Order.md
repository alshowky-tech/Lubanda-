---
title: "Build Order"
code: "LCS-IMP-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Implementation Plan"
language: "English"
---

# Build Order

**Specification Code:** `LCS-IMP-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Implementation Plan

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Milestone 1 — Contracts

Implement all domain types, issue codes, configuration schemas, and stage result types.

## Milestone 2 — Genealogy Core

Implement import, normalization, validation, and graph indexes.

## Milestone 3 — Geometry Core

Implement vectors, bounds, Bézier operations, intersections, and spatial hash.

## Milestone 4 — Demand and Territory

Implement subtree metrics and first territory allocator.

## Milestone 5 — Skeleton MVP

Implement trunk, primary branches, recursive child paths, and deterministic candidate scoring.

## Milestone 6 — Collision Safety

Implement broad and narrow phase checks and local repair.

## Milestone 7 — Labels

Implement real Arabic text measurement and label candidate solver.

## Milestone 8 — Stability

Implement prior-layout constraints and incremental reflow.

## Milestone 9 — Scale

Workers, checkpoints, profiling, and 1,500-person benchmark.

## Milestone 10 — Visual Layer

Bark, leaves, themes, and templates.

## Milestone 11 — Export and Production UI

Complete output formats and workflow.

No milestone SHOULD begin before the previous milestone's mandatory gate passes.
