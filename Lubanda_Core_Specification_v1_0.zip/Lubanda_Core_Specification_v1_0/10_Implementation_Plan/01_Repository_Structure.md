---
title: "Repository Structure"
code: "LCS-IMP-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Implementation Plan"
language: "English"
---

# Repository Structure

**Specification Code:** `LCS-IMP-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Implementation Plan

> Truth before beauty. Growth before drawing. Architecture before code.

---

```text
src/
  core/
    genealogy/
      types.ts
      graph.ts
      normalize.ts
    validation/
      validator.ts
      issue-codes.ts
    geometry/
      vec2.ts
      bounds.ts
      bezier.ts
      intersections.ts
    spatial/
      SpatialHash.ts
    demand/
      DemandEngine.ts
    territory/
      TerritorySolver.ts
    skeleton/
      SkeletonEngine.ts
      PathCandidateGenerator.ts
      PathScorer.ts
    collision/
      CollisionEngine.ts
      CollisionResolver.ts
    labels/
      TextMeasurementService.ts
      LabelLayoutEngine.ts
    stability/
      IncrementalLayoutEngine.ts
      ConstraintManager.ts
    solve/
      SolveCoordinator.ts
      checkpoints.ts
    diagnostics/
      events.ts
      debug-scene.ts
    visual/
      VisualRenderer.ts
    export/
      SvgExporter.ts
      PngExporter.ts
      PdfExporter.ts
  app-services/
  workers/
  ui/
tests/
  unit/
  property/
  integration/
  visual/
  performance/
```
