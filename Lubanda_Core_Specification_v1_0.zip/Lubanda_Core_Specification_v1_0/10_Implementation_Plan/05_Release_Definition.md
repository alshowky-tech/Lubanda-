---
title: "Core Engine v1.0 Release Definition"
code: "LCS-IMP-005"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Implementation Plan"
language: "English"
---

# Core Engine v1.0 Release Definition

**Specification Code:** `LCS-IMP-005`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Implementation Plan

> Truth before beauty. Growth before drawing. Architecture before code.

---

Core Engine v1.0 is complete when:

- `.xlsx` genealogy import works,
- required validation rules work,
- selected subtree is built,
- demand values are computed,
- territories are allocated,
- continuous skeleton is generated,
- no forbidden crossings remain,
- Arabic labels are placed without overlap,
- local additions preserve unrelated geometry,
- deterministic replay passes,
- official 1,500-person benchmark passes,
- debug output explains failures,
- approved skeleton can be exported as SVG.

Bark rendering is not required for Core Engine v1.0.
