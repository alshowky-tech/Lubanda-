---
title: "AI Coding Assistant Workflow"
code: "LCS-IMP-004"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Implementation Plan"
language: "English"
---

# AI Coding Assistant Workflow

**Specification Code:** `LCS-IMP-004`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Implementation Plan

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Task Prompt Template

```text
Implement <module/file> according to:
- Specification code:
- Inputs:
- Outputs:
- Hard constraints:
- Error codes:
- Required tests:
- Performance expectations:

Do not modify unrelated files.
Do not introduce new architecture without an engineering decision record.
Return changed files, tests, and known limitations.
```

## Review Checklist

- matches public interface,
- no hidden mutation,
- deterministic,
- tests included,
- diagnostics included,
- no UI coupling,
- no visual workaround for structural defect.

## Small-Batch Rule

One AI task SHOULD implement one coherent module or one narrowly defined feature.
