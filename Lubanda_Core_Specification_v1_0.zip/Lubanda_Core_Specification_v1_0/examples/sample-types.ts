export type Brand<T, B extends string> = T & { readonly __brand: B };

export type PersonId = Brand<string, "PersonId">;
export type BranchId = Brand<string, "BranchId">;
export type EdgeId = Brand<string, "EdgeId">;

export interface Vec2 {
  readonly x: number;
  readonly y: number;
}

export interface CubicBezier {
  readonly p0: Vec2;
  readonly p1: Vec2;
  readonly p2: Vec2;
  readonly p3: Vec2;
}

export interface Person {
  readonly id: PersonId;
  readonly name: string;
  readonly parentId: PersonId | null;
  readonly generation: number;
}
