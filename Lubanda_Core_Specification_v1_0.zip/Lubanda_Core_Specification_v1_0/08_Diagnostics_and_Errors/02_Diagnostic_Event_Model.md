---
title: "Diagnostic Event Model"
code: "LCS-DIA-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Diagnostics and Errors"
language: "English"
---

# Diagnostic Event Model

**Specification Code:** `LCS-DIA-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Diagnostics and Errors

> Truth before beauty. Growth before drawing. Architecture before code.

---

```ts
interface DiagnosticEvent {
  timestamp: number;
  solveId: string;
  stage: string;
  eventType: string;
  entityId?: string;
  durationMs?: number;
  metrics?: Readonly<Record<string, number>>;
  payload?: Readonly<Record<string, unknown>>;
}
```

## Required Events

- stage start/end,
- candidate generated,
- candidate rejected,
- collision detected,
- territory renegotiated,
- label backtrack,
- local re-solve,
- checkpoint saved,
- final validation.

## Production Policy

Verbose geometric payloads MAY be disabled in production, but aggregate diagnostics MUST remain.
