---
title: "Debug Visualizations"
code: "LCS-DIA-002"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Diagnostics and Errors"
language: "English"
---

# Debug Visualizations

**Specification Code:** `LCS-DIA-002`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Diagnostics and Errors

> Truth before beauty. Growth before drawing. Architecture before code.

---

The application SHOULD provide toggles for:

- skeleton centerlines,
- control points,
- collision envelopes,
- spatial index cells,
- territory polygons,
- demand values,
- label candidate boxes,
- rejected path candidates,
- boundary distance field,
- stability anchors,
- branch ownership,
- solve iteration heat map.

Debug visuals MUST not alter solve behavior.
