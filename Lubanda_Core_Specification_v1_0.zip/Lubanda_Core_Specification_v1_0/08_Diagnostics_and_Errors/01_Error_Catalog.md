---
title: "Error Catalog"
code: "LCS-ERR-001"
document: "Lubanda Core Specification"
version: "1.0"
status: "Official Baseline"
section: "Diagnostics and Errors"
language: "English"
---

# Error Catalog

**Specification Code:** `LCS-ERR-001`  
**Core Specification Version:** `1.0`  
**Status:** Official Baseline  
**Section:** Diagnostics and Errors

> Truth before beauty. Growth before drawing. Architecture before code.

---

## Data Errors

- `EMPTY_FILE`
- `MISSING_COLUMN`
- `EMPTY_ID`
- `EMPTY_NAME`
- `DUPLICATE_ID`
- `SELF_PARENT`
- `MISSING_PARENT`
- `NO_ROOT`
- `MULTIPLE_ROOTS`
- `CYCLE`
- `GENERATION_MISMATCH`
- `UNREACHABLE_PERSON`

## Solve Errors

- `TERRITORY_STARVATION`
- `NO_VALID_PATH_CANDIDATE`
- `JUNCTION_CONSTRAINT_FAILURE`
- `BRANCH_COLLISION_UNRESOLVED`
- `BOUNDARY_CONSTRAINT_FAILURE`
- `LABEL_PLACEMENT_IMPOSSIBLE`
- `LAYOUT_NOT_DETERMINISTIC`
- `SOLVE_CANCELLED`
- `SOLVE_TIMEOUT`

## Visual Errors

- `UNAPPROVED_LAYOUT`
- `BARK_ENVELOPE_VIOLATION`
- `LABEL_OBSCURED_AFTER_RENDER`
- `EXPORT_DIMENSION_INVALID`
- `FONT_UNAVAILABLE`

## Error Shape

```ts
interface EngineIssue {
  code: string;
  severity: "FATAL" | "ERROR" | "WARNING" | "INFO";
  messageKey: string;
  entityIds?: readonly string[];
  stage: SolveStage | "IMPORT" | "EXPORT";
  details?: Readonly<Record<string, unknown>>;
  recoverable: boolean;
}
```
