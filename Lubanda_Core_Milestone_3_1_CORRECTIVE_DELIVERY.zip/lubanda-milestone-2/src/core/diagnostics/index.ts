export * from "./DiagnosticCollector.js";

