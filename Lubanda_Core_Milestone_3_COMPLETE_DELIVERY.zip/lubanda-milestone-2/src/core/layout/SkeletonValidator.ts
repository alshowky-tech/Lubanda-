import { classifyPointInPolygon } from "../geometry/polygon.js";
import { boundsOverlap } from "../geometry/bounds.js";
import type { Polygon, Bounds } from "../geometry/types.js";
import { intersectSegments } from "../geometry/segments.js";
import type { PersonId } from "../contracts/identifiers.js";
import type { EngineIssue } from "../contracts/issues.js";
import type { GenealogyGraph } from "../genealogy/graph.js";
import type {
  SkeletonPlan,
  SkeletonValidationReport,
  SkeletonValidationMetrics,
} from "../skeleton/types.js";

const issue = (
  code: string,
  stage: string,
  messageKey: string,
  entityIds: readonly string[] = [],
  details: Readonly<Record<string, unknown>> = {},
): EngineIssue => ({
  code,
  severity: "ERROR",
  messageKey,
  stage,
  ...(entityIds.length === 0 ? {} : { entityIds }),
  details,
  recoverable: true,
}) as unknown as EngineIssue;

/**
 * Validates a grown skeleton plan against structural, geometric, and
 * genealogical correctness constraints.
 *
 * Checks:
 * - Every branch has a valid parent chain
 * - Every person in the selected-root subtree has a corresponding branch
 * - No branch curves cross territory boundaries
 * - No branch curves intersect each other
 * - All branches are within the template polygon
 * - The trunk is properly connected from base to terminal
 */
export class SkeletonValidator {
  validate(
    plan: SkeletonPlan,
    graph: GenealogyGraph,
    selectedRootId: PersonId,
    templatePolygon: Polygon,
    territoryPolygons: ReadonlyMap<PersonId, Polygon>,
  ): SkeletonValidationReport {
    const issues: EngineIssue[] = [];
    const epsilon = 1e-7;
    const branchMap = new Map(plan.branches.map((b) => [b.id, b]));
    const nodeMap = new Map(plan.nodes.map((n) => [n.id, n]));
    const branchBoundsList: Bounds[] = [];
    let invalidBranchCount = 0;
    let missingPersonBranchCount = 0;
    let orphanBranchCount = 0;
    let territoryMissCount = 0;
    let outOfBoundsCount = 0;
    let intersectionCount = 0;

    // 1. Check that all persons in the genealogy (under selected root)
    //    have a corresponding branch
    const subtree = graph.getSubtree(selectedRootId);
    const personsWithBranches = new Set(
      plan.branches.map((b) => b.ownerPersonId),
    );
    for (const personId of subtree) {
      if (!personsWithBranches.has(personId)) {
        missingPersonBranchCount += 1;
        issues.push(
          issue(
            "SKELETON_MISSING_PERSON",
            "VALIDATE_SKELETON",
            "skeleton.missingPerson",
            [personId],
          ),
        );
      }
    }

    // 2. Check each branch for structural integrity
    for (const branch of plan.branches) {
      // Check parent chain
      if (branch.parentBranchId !== null) {
        const parent = branchMap.get(branch.parentBranchId);
        if (!parent) {
          orphanBranchCount += 1;
          issues.push(
            issue(
              "SKELETON_ORPHAN_BRANCH",
              "VALIDATE_SKELETON",
              "skeleton.orphanBranch",
              [branch.id],
            ),
          );
        }
      }

      // Check that start node exists
      if (!nodeMap.has(branch.startNodeId)) {
        invalidBranchCount += 1;
        issues.push(
          issue(
            "SKELETON_BRANCH_INVALID",
            "VALIDATE_SKELETON",
            "skeleton.branchInvalid",
            [branch.id],
            { reason: "startNodeId not found" },
          ),
        );
      }

      // Check that end node exists
      if (!nodeMap.has(branch.endNodeId)) {
        invalidBranchCount += 1;
        issues.push(
          issue(
            "SKELETON_BRANCH_INVALID",
            "VALIDATE_SKELETON",
            "skeleton.branchInvalid",
            [branch.id],
            { reason: "endNodeId not found" },
          ),
        );
      }

      // Check that branch points are within template
      const allPoints = [
        branch.curve.p0,
        branch.curve.p1,
        branch.curve.p2,
        branch.curve.p3,
      ];
      for (const point of allPoints) {
        if (classifyPointInPolygon(point, templatePolygon) === "OUTSIDE") {
          outOfBoundsCount += 1;
          issues.push(
            issue(
              "SKELETON_BRANCH_OUT_OF_BOUNDS",
              "VALIDATE_SKELETON",
              "skeleton.branchOutOfBounds",
              [branch.id],
            ),
          );
          break;
        }
      }

      // Check territory polygon containment for this branch
      const territoryPoly = branch.territoryId
        ? [...territoryPolygons.values()].find(
            (p) =>
              classifyPointInPolygon(branch.curve.p0, p) !== "OUTSIDE" ||
              classifyPointInPolygon(branch.curve.p3, p) !== "OUTSIDE",
          )
        : null;
      if (branch.territoryId !== null && territoryPoly === null) {
        territoryMissCount += 1;
        issues.push(
          issue(
            "SKELETON_TERRITORY_MISS",
            "VALIDATE_SKELETON",
            "skeleton.territoryMiss",
            [branch.id],
          ),
        );
      }

      branchBoundsList.push({
        minX: Math.min(...allPoints.map((p) => p.x)),
        minY: Math.min(...allPoints.map((p) => p.y)),
        maxX: Math.max(...allPoints.map((p) => p.x)),
        maxY: Math.max(...allPoints.map((p) => p.y)),
      });
    }

    // 3. Check for branch intersections
    const branchesArray = plan.branches;
    for (let left = 0; left < branchesArray.length; left += 1) {
      const leftBranch = branchesArray[left]!;
      const leftPoints = [
        leftBranch.curve.p0,
        leftBranch.curve.p1,
        leftBranch.curve.p2,
        leftBranch.curve.p3,
      ];
      for (let right = left + 1; right < branchesArray.length; right += 1) {
        const rightBranch = branchesArray[right]!;

        // Quick bounds check
        const leftBounds = branchBoundsList[left]!;
        const rightBounds = branchBoundsList[right]!;
        if (!boundsOverlap(leftBounds, rightBounds)) continue;

        // Check each segment pair
        for (
          let leftSeg = 0;
          leftSeg < leftPoints.length - 1;
          leftSeg += 1
        ) {
          const la = leftPoints[leftSeg]!;
          const lb = leftPoints[leftSeg + 1]!;
          for (
            let rightSeg = 0;
            rightSeg < leftPoints.length - 1;
            rightSeg += 1
          ) {
            const ra = leftPoints[rightSeg]!;
            const rb = leftPoints[rightSeg + 1]!;
            // Skip trivial comparisons
            if (la === ra && lb === rb) continue;
            const result = intersectSegments(la, lb, ra, rb, { epsilon });
            if (result.kind !== "NONE") {
              intersectionCount += 1;
              issues.push(
                issue(
                  "SKELETON_BRANCH_INTERSECTION",
                  "VALIDATE_SKELETON",
                  "skeleton.branchIntersection",
                  [leftBranch.id, rightBranch.id],
                  { kind: result.kind },
                ),
              );
            }
          }
        }
      }
    }

    // 4. Check trunk completeness
    const trunkNodeIds = new Set<string>();
    for (const trunkBranchId of plan.trunk.segments) {
      const trunkBranch = branchMap.get(trunkBranchId);
      if (!trunkBranch) {
        issues.push(
          issue(
            "SKELETON_TRUNK_INVALID",
            "VALIDATE_SKELETON",
            "skeleton.trunkInvalid",
            [trunkBranchId],
          ),
        );
      } else {
        trunkNodeIds.add(trunkBranch.startNodeId);
        trunkNodeIds.add(trunkBranch.endNodeId);
      }
    }

    // 5. Check root node exists
    if (!nodeMap.has(plan.trunk.baseNodeId)) {
      issues.push(
        issue(
          "SKELETON_TRUNK_INVALID",
          "VALIDATE_SKELETON",
          "skeleton.trunkInvalid",
          [],
          { reason: "baseNodeId not found" },
        ),
      );
    }

    const metrics: SkeletonValidationMetrics = {
      branchCount: plan.branches.length,
      nodeCount: plan.nodes.length,
      trunkSegmentCount: plan.trunk.segments.length,
      junctionCount: plan.mappedJunctions.length,
      invalidBranchCount,
      missingPersonBranchCount,
      orphanBranchCount,
      territoryMissCount,
      outOfBoundsCount,
      intersectionCount,
      totalCurveLength: plan.branches.reduce(
        (sum, b) => sum + b.length,
        0,
      ),
      maxDepth: plan.metadata.maximumGenealogyDepth,
      acceptedPersonCount: plan.branches.length,
      connectedPersonCount: plan.branches.filter(
        (b) => b.parentBranchId !== null || b.generation === 0,
      ).length,
    };

    return {
      accepted: issues.length === 0,
      issues: Object.freeze(issues),
      metrics,
    };
  }
}
