import { describe, expect, it } from "vitest";
import {
  acceptedSnapshot,
  syntheticSnapshot,
} from "../../helpers/genealogy-builders.js";
import { growSkeleton } from "../../helpers/skeleton-builders.js";

describe("DeterministicSkeletonGrowthEngine", () => {
  it("grows a valid trunk and branches for a simple genealogy", async () => {
    const { skeletonPlan } = await growSkeleton(acceptedSnapshot());
    expect(skeletonPlan.status).toBe("ACCEPTED");
    expect(skeletonPlan.trunk.segments.length).toBeGreaterThanOrEqual(1);
    expect(skeletonPlan.branches.length).toBeGreaterThanOrEqual(1);
    expect(skeletonPlan.nodes.length).toBeGreaterThanOrEqual(2);
  });

  it("connects major lineages via mapped junctions", async () => {
    const { skeletonPlan } = await growSkeleton(acceptedSnapshot());
    expect(skeletonPlan.mappedJunctions.length).toBeGreaterThanOrEqual(1);
    for (const junction of skeletonPlan.mappedJunctions) {
      expect(junction.trunkNodeId).toBeTruthy();
      expect(junction.lineageRootId).toBeTruthy();
    }
  });

  it("every branch has a valid curve with finite coordinates", async () => {
    const { skeletonPlan } = await growSkeleton(acceptedSnapshot());
    for (const branch of skeletonPlan.branches) {
      expect(Number.isFinite(branch.curve.p0.x)).toBe(true);
      expect(Number.isFinite(branch.curve.p0.y)).toBe(true);
      expect(Number.isFinite(branch.curve.p3.x)).toBe(true);
      expect(Number.isFinite(branch.curve.p3.y)).toBe(true);
      expect(branch.length).toBeGreaterThan(0);
    }
  });

  it("every node has a valid point within the template", async () => {
    const { skeletonPlan } = await growSkeleton(acceptedSnapshot());
    for (const node of skeletonPlan.nodes) {
      expect(Number.isFinite(node.point.x)).toBe(true);
      expect(Number.isFinite(node.point.y)).toBe(true);
      expect(node.point.x).toBeGreaterThanOrEqual(0);
      expect(node.point.y).toBeGreaterThanOrEqual(0);
    }
  });

  it("accepts a single-person genealogy gracefully", async () => {
    const { skeletonPlan } = await growSkeleton(
      syntheticSnapshot({ size: 1 }),
    );
    expect(skeletonPlan.status).toBe("ACCEPTED");
    expect(skeletonPlan.branches.length).toBeGreaterThanOrEqual(1);
  });

  it("records diagnostic events during growth", async () => {
    const { skeletonPlan } = await growSkeleton(acceptedSnapshot());
    expect(skeletonPlan.diagnostics.length).toBeGreaterThan(0);
    const stages = new Set(
      skeletonPlan.diagnostics.map((d) => d.stage),
    );
    expect(stages.has("TRUNK_PLANNING")).toBe(true);
    expect(stages.has("RECURSIVE_GROWTH")).toBe(true);
  });

  it("produces a deterministic fingerprint", async () => {
    const first = await growSkeleton(acceptedSnapshot());
    const second = await growSkeleton(acceptedSnapshot());
    expect(first.skeletonPlan.deterministicFingerprint).toBe(
      second.skeletonPlan.deterministicFingerprint,
    );
  });

  it("assigns non-null candidate scores to at least some branches", async () => {
    const { skeletonPlan } = await growSkeleton(
      syntheticSnapshot({ size: 10, shape: "BALANCED" }),
    );
    const scoredBranches = skeletonPlan.branches.filter(
      (b) => b.candidateScore !== null,
    );
    expect(scoredBranches.length).toBeGreaterThan(0);
  });
});
