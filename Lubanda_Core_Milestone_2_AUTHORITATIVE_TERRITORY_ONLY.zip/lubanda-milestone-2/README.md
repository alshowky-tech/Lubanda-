# Lubanda Core — Milestone 2

This repository preserves Milestone 1 and implements only the second approved engineering milestone of the
Lubanda Natural Genealogy Growth Platform:

`Demand Computation → Territory Allocation → Corridor Planning → Territory Validation → Diagnostics → Automated Tests → Documentation`

It intentionally contains no UI, skeleton growth, final branch routing, collision
resolver, label engine, artistic renderer, AI adapter, or export engine.

## Commands

```bash
npm run typecheck
npm run lint
npm run test:unit
npm run test:property
npm run test:integration
npm run test:schema
npm run diagnostic:svg
npm run diagnostic:territory-svg
npm run benchmark:official
```

To validate the private official workbook without copying it into the project:

```bash
LUBANDA_OFFICIAL_WORKBOOK=/absolute/path/to/workbook.xlsx npm run validate:official
LUBANDA_OFFICIAL_WORKBOOK=/absolute/path/to/workbook.xlsx npm run benchmark:official
```

## Governing documents

- The Lubanda Bible — Official First Edition
- Lubanda Core Specification v1.0
- Approved Core v1 contract clarifications dated 2026-07-27
