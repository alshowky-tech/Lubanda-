export const MILESTONE_1_STAGES = [
  "ACQUIRE",
  "NORMALIZE",
  "VALIDATE",
  "BUILD_GRAPH",
  "CONFIGURATION",
] as const;

export type Milestone1Stage = (typeof MILESTONE_1_STAGES)[number];

export const MILESTONE_2_STAGES = [
  "COMPUTE_DEMAND",
  "ALLOCATE_TERRITORIES",
  "PLAN_CORRIDORS",
  "NEGOTIATE_TERRITORIES",
  "VALIDATE_TERRITORIES",
  "SERIALIZE_TERRITORIES",
] as const;

export type Milestone2Stage = (typeof MILESTONE_2_STAGES)[number];
export type CoreStage = Milestone1Stage | Milestone2Stage;
