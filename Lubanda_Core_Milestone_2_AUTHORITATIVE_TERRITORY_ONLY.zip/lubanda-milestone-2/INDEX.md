# Lubanda Core documentation index

- `README.md` — package scope and commands.
- `docs/architecture/milestone-1-architecture.md` — preserved baseline.
- `docs/architecture/milestone-2-architecture.md` — demand and territory architecture.
- `docs/architecture/milestone-2-dependency-graph.md` — dependency direction.
- `docs/configuration/milestone-2-configuration.md` — configuration reference.
- `docs/decisions/0001-milestone-1-contract-clarifications.md` — approved Core v1 clarifications.
- `docs/decisions/0002-milestone-2-contract-extension.md` — additive Milestone 2 contract decision.
- `docs/catalogs/milestone-2-issues-and-diagnostics.md` — issue and diagnostic catalog.
- `docs/traceability/milestone-1-matrix.md` — preserved baseline traceability.
- `docs/traceability/milestone-2-matrix.md` — Milestone 2 traceability.
- `docs/milestone-2-completion-report.md` — completion evidence.
- `docs/milestone-2-known-limitations.md` — known limits and risks.
- `docs/milestone-3-proposed-file-plan.md` — approval-gated next milestone plan.

This file resolves the non-blocking documentation-manifest discrepancy recorded
in the approved Core v1 contract clarifications.
